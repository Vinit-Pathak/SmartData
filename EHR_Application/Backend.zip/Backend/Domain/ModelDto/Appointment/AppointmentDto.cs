﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ModelDto.Appointment
{
    public class AppointmentDto
    {
        public int PatientId { get; set; }
        public int ProviderId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public TimeSpan AppointmentTime { get; set; }
        public string ChiefComplaint { get; set; }
        public int SpecialisationId { get; set; }
        public string AppointmentStatus { get; set; }
        public float Fee { get; set; }

        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public string SpecializationName { get; set; }
    }
}

