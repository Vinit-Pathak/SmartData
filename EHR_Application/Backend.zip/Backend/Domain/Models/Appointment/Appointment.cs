﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models.Appointment
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public int PatientId { get; set; }
        public int ProviderId { get; set; }
        public int SpecialisationId { get; set; }
        public DateTime AppointmentDate { get; set; }
        public TimeSpan AppointmentTime { get; set; }
        public string ChiefComplaint { get; set; }
        public string AppointmentStatus { get; set; } // Scheduled, Completed, Canceled
        public float Fee { get; set; }
    }


    //public enum AppointmentStatus
    //{
    //    Scheduled,
    //    Completed,
    //    Canceled
    //}
}
