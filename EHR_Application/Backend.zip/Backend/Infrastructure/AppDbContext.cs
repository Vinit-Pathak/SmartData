﻿using Core.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure    
{
    public class AppDbContext : DbContext, IAppDbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        DbSet<Domain.Models.User.User> Users { get; set; }
        DbSet<Domain.Models.User.UserType> UserTypes { get; set; }
        DbSet<Domain.Models.Otp.Otp> Otps { get; set; }
        DbSet<Domain.Models.CountryState.Country> Countries { get; set; }
        DbSet<Domain.Models.CountryState.State> States { get; set; }
        DbSet<Domain.Models.Specialisation.Specialization> Specializations { get; set; }
        public IDbConnection GetConnection()
        {
            return this.Database.GetDbConnection();
        }
    }
}
