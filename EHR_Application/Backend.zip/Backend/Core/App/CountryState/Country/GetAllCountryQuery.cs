﻿using Core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.CountryState.Country
{
    public class GetAllCountryQuery:IRequest<List<Domain.Models.CountryState.Country>>
    {
    }

    public class GetAllCountryQueryHandler : IRequestHandler<GetAllCountryQuery, List<Domain.Models.CountryState.Country>>
    {
        private readonly IAppDbContext _context;

        public GetAllCountryQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Domain.Models.CountryState.Country>> Handle(GetAllCountryQuery request, CancellationToken cancellationToken)
        {
            var country = await _context.Set<Domain.Models.CountryState.Country>().ToListAsync();
            return country;
        }
    }
}
