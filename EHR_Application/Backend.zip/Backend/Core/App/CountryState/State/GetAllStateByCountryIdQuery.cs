﻿using Core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.CountryState.State
{
    public class GetAllStateByCountryIdQuery:IRequest<List<Domain.Models.CountryState.State>>
    {
        public int CountryId { get; set; }
    }

    public class GetAllStateByCountryIdQueryHandler : IRequestHandler<GetAllStateByCountryIdQuery, List<Domain.Models.CountryState.State>>
    {
        private readonly IAppDbContext _context;

        public GetAllStateByCountryIdQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public Task<List<Domain.Models.CountryState.State>> Handle(GetAllStateByCountryIdQuery request, CancellationToken cancellationToken)
        {
            var allStateByCountryId = _context.Set<Domain.Models.CountryState.State>()
                .Where(state => state.CountryId == request.CountryId).ToListAsync();
            return allStateByCountryId;
        }
    }
}
