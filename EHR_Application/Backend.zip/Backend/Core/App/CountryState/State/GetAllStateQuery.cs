﻿using Core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.CountryState.State
{
    public class GetAllStateQuery:IRequest<List<Domain.Models.CountryState.State>>
    {
    }

    public class GetAllStateHandler : IRequestHandler<GetAllStateQuery, List<Domain.Models.CountryState.State>>
    {
        private readonly IAppDbContext _context;

        public GetAllStateHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Domain.Models.CountryState.State>> Handle(GetAllStateQuery request, CancellationToken cancellationToken)
        {
            var allState = await _context.Set<Domain.Models.CountryState.State>().ToListAsync();
            return allState;
        }
    }
}
