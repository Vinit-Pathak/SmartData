﻿using Core.Interface;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using Domain.Models.Appointment;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Command
{
    public class CreateAppointmentCommand : IRequest<AppResponse<object>>
    {
        public CreateAppointmentDto CreateAppointmentDto { get; set; }
    }

    public class CreateAppointmentCommandHandler : IRequestHandler<CreateAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;

        public CreateAppointmentCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<AppResponse<object>> Handle(CreateAppointmentCommand request, CancellationToken cancellationToken)
        {

            var checkAppointment = await _context.Set<Domain.Models.Appointment.Appointment>()
               .FirstOrDefaultAsync(a => a.AppointmentId == request.CreateAppointmentDto.AppointmentId);

            if (checkAppointment != null)
            {
                return AppResponse.Fail<object>(message: "Appointment already exists", statusCode: HttpStatusCodes.Conflict);
            }

            var charges = await _context.Set<Domain.Models.User.User>().FirstOrDefaultAsync(a => a.UserId == request.CreateAppointmentDto.ProviderId);

            var appointment = new Domain.Models.Appointment.Appointment
            {
                PatientId = request.CreateAppointmentDto.PatientId,
                ProviderId = request.CreateAppointmentDto.ProviderId,
                AppointmentDate = request.CreateAppointmentDto.AppointmentDate,
                AppointmentTime = request.CreateAppointmentDto.AppointmentTime,
                AppointmentStatus = "Scheduled",
                ChiefComplaint = request.CreateAppointmentDto.ChiefComplaint,
                Fee = (float)charges.VisitingCharge,
                SpecialisationId = request.CreateAppointmentDto.SpecialisationId

            };

            await _context.Set<Domain.Models.Appointment.Appointment>().AddAsync(appointment);
            await _context.SaveChangesAsync(cancellationToken);

           return AppResponse.Success<object>(message: "Appointment created successfully", statusCode: HttpStatusCodes.Created);

        }
    }
}
