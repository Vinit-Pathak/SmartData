﻿using Azure.Core;
using Core.Interface;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Patient.Query
{
    public class GetProviderBySpecialityQuery : IRequest<AppResponse<object>>
    {
        public int SpecialisationId { get; set; }
    }

    public class GetProviderBySpecialityQueryHandler : IRequestHandler<GetProviderBySpecialityQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;

        public GetProviderBySpecialityQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<AppResponse<object>> Handle(GetProviderBySpecialityQuery request, CancellationToken cancellationToken)
        {
            //var providerData = await _context.Set<Domain.Models.User.User>()
            //    .Where(x => x.SpecializationId == request.SpecialisationId)
            //    .Select(x => new
            //    {
            //        UserId = x.UserId,
            //        FirstName = x.FirstName,
            //        LastName = x.LastName,
            //    }).ToListAsync(cancellationToken);

            var specialisation = await _context.Set<Domain.Models.Specialisation.Specialization>().Where(a => a.SpecializationId == request.SpecialisationId).FirstOrDefaultAsync();

            if (specialisation == null)
            {
                return AppResponse.Fail<object>(message: "Specialisation not found", statusCode: HttpStatusCodes.NotFound);
            }

            var providerData = await _context.Set<Domain.Models.User.User>()
                .Where(x => x.SpecializationId == request.SpecialisationId
                      && x.UserTypeId == 2 && !x.IsDeleted).ToListAsync(cancellationToken);

            return AppResponse.Success<object>(message: "Data retrieved successfully", data: providerData, statusCode: HttpStatusCodes.OK);
        }
    }
}