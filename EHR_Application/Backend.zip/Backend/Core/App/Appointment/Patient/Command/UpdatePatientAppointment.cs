﻿using Core.Interface;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Patient.Command
{
    public class UpdatePatientAppointment : IRequest<AppResponse<object>>
    {
        public UpdatePatientAppointmentDto UpdatePatientAppointmentDto { get; set; }
    }

    public class UpdatePatientAppointmentHandler : IRequestHandler<UpdatePatientAppointment, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;

        public UpdatePatientAppointmentHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<AppResponse<object>> Handle(UpdatePatientAppointment request, CancellationToken cancellationToken)
        {
            var appointmentId = request.UpdatePatientAppointmentDto.AppointmentId;
            var appointment = await _context.Set<Domain.Models.Appointment.Appointment>()
                .FirstOrDefaultAsync(a => a.AppointmentId == appointmentId
                && a.AppointmentStatus == "Scheduled");
            if (appointment == null) {
                return AppResponse.Fail<object>(message: "Appointment not found", statusCode: HttpStatusCodes.NotFound);
            }

            appointment.AppointmentDate = request.UpdatePatientAppointmentDto.AppointmentDate;
            appointment.AppointmentTime = request.UpdatePatientAppointmentDto.AppointmentTime;
            appointment.ChiefComplaint = request.UpdatePatientAppointmentDto.ChiefComplaint;

            var patient = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(x => x.UserId == appointment.PatientId);
            var provider = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(x => x.UserId == appointment.ProviderId);

            await _context.SaveChangesAsync(cancellationToken);

            await _emailService.SendEmailAsync(
                patient.Email,
                "Appointment Updated",
                $"Your appointment with {provider.FirstName} {provider.LastName} has been updated. The new date is {request.UpdatePatientAppointmentDto.AppointmentDate.ToShortDateString()} at {request.UpdatePatientAppointmentDto.AppointmentTime.ToString()}"
            );

            await _emailService.SendEmailAsync(
                provider.Email,
                "Appointment Updated",
                $"Your appointment with {patient.FirstName} {patient.LastName} has been updated. The new date is {request.UpdatePatientAppointmentDto.AppointmentDate.ToShortDateString()} at {request.UpdatePatientAppointmentDto.AppointmentTime.ToString()}"
            );

            return AppResponse.Success<object>(message: "Appointment updated successfully", statusCode:HttpStatusCodes.OK, data:appointment);


        }
    }
}
