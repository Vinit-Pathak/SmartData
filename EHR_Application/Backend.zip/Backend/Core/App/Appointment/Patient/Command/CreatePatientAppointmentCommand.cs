﻿using Core.Interface;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Core.App.Appointment.Patient.Command
{
    public class CreatePatientAppointmentCommand : IRequest<AppResponse<object>>
    {
        public PatientAppointmentDto PatientAppointmentDto { get; set; }
    }

    public class CreateAppointmentCommandHandler : IRequestHandler<CreatePatientAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
        private readonly IRazorpayService _razorpayService;

        public CreateAppointmentCommandHandler(IAppDbContext context, IEmailService emailService, IRazorpayService razorpayService)
        {
            _context = context;
            _emailService = emailService;
            _razorpayService = razorpayService;
        }
        public async Task<AppResponse<object>> Handle(CreatePatientAppointmentCommand request, CancellationToken cancellationToken)
        {

            var existingAppointment = await _context.Set<Domain.Models.Appointment.Appointment>()
                                .FirstOrDefaultAsync(a =>
                                    a.ProviderId == request.PatientAppointmentDto.ProviderId &&
                                    a.PatientId == request.PatientAppointmentDto.PatientId &&
                                    a.AppointmentDate == request.PatientAppointmentDto.AppointmentDate &&
                                    a.AppointmentTime == request.PatientAppointmentDto.AppointmentTime);

            if (existingAppointment != null)
            {
                return AppResponse.Fail<object>(
                    message: "An appointment already exists for the given time and date",
                    statusCode: HttpStatusCodes.Conflict
                );
            }

            var patient = await _context.Set<Domain.Models.User.User>()
                 .FirstOrDefaultAsync(u => u.UserId == request.PatientAppointmentDto.PatientId);
            var provider = await _context.Set<Domain.Models.User.User>()
                 .FirstOrDefaultAsync(u => u.UserId == request.PatientAppointmentDto.ProviderId);
           
            var paymentData = await _razorpayService.VerifyPaymentAsync(request.PatientAppointmentDto.PaymentId, request.PatientAppointmentDto.OrderId);

            var appointment = new Domain.Models.Appointment.Appointment
            {
                PatientId = request.PatientAppointmentDto.PatientId,
                ProviderId = request.PatientAppointmentDto.ProviderId,
                AppointmentDate = request.PatientAppointmentDto.AppointmentDate,
                AppointmentTime = request.PatientAppointmentDto.AppointmentTime,
                AppointmentStatus = "Scheduled",
                ChiefComplaint = request.PatientAppointmentDto.ChiefComplaint,
                Fee = (float)provider.VisitingCharge,
                SpecialisationId = request.PatientAppointmentDto.SpecializationId
            };

            await _context.Set<Domain.Models.Appointment.Appointment>().AddAsync(appointment);
            await _context.SaveChangesAsync();

            await _emailService.SendEmailAsync(patient.Email, "Appointment Created", $"Your appointment with {provider.FirstName} {provider.LastName} has been scheduled for {appointment.AppointmentDate} at {appointment.AppointmentTime}.");

            await _emailService.SendEmailAsync(provider.Email, "Appointment Created", $"You have an appointment with {patient.FirstName} {patient.LastName} has been scheduled for {appointment.AppointmentDate} at {appointment.AppointmentTime}.");

            return AppResponse.Success<object>(message: "Appointment created successfully", statusCode: HttpStatusCodes.OK, data: paymentData);

        }
    }
}
