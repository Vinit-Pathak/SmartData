﻿using Core.Interface;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Patient.Command
{
    public class CancelPatientAppointmentCommand: IRequest<AppResponse<object>>
    {
        public int AppointmentId { get; set; }
    }

    public class CancelPatientAppointmentCommandHandler : IRequestHandler<CancelPatientAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;

        public CancelPatientAppointmentCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<AppResponse<object>> Handle(CancelPatientAppointmentCommand request, CancellationToken cancellationToken)
        {
            var appointment = await _context.Set<Domain.Models.Appointment.Appointment>()
                .FirstOrDefaultAsync(a => a.AppointmentId == request.AppointmentId);

            if (appointment == null)
            {
                return AppResponse.Fail<object>(message: "Appointment not found", statusCode: HttpStatusCodes.NotFound);
            }

            appointment.AppointmentStatus = "Cancelled";
            _context.Set<Domain.Models.Appointment.Appointment>().Update(appointment);
            await _context.SaveChangesAsync();

            var patient = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(u => u.UserId == appointment.PatientId);
            var provider = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(u => u.UserId == appointment.ProviderId);

            await _emailService.SendEmailAsync(patient.Email, "Appointment Cancelled", $"Your appointment with {provider.FirstName} {provider.LastName} has been cancelled.");
            await _emailService.SendEmailAsync(provider.Email, "Appointment Cancelled", $"Your appointment with {patient.FirstName} {patient.LastName} has been cancelled.");

            return AppResponse.Success<object>(message: "Appointment cancelled successfully", statusCode: HttpStatusCodes.OK, data: appointment);
        }
    }
}
