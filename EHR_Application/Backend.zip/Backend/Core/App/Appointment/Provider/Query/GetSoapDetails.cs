﻿using Core.Interface;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Provider.Query
{
    public class GetSoapDetails: IRequest<AppResponse<object>>
    {
        public int AppointmentId { get; set; }
    }

    public class GetSoapDetailsHandler : IRequestHandler<GetSoapDetails, AppResponse<object>> 
    {
        private readonly IAppDbContext _context;

        public GetSoapDetailsHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<AppResponse<object>> Handle(GetSoapDetails request, CancellationToken cancellationToken)
        {
            var soapData = await _context.Set<Domain.Models.Appointment.SOAPNotes>()
                .FirstOrDefaultAsync(x => x.SOAPNotesId == request.AppointmentId);
            if (soapData == null)
            {
                return AppResponse.Fail<object>(message: "Data not found", statusCode: HttpStatusCodes.NotFound);
            }
            return AppResponse.Success<object>(message: "SOAP Notes fetched successfully", statusCode: HttpStatusCodes.OK, data: soapData);
        }
    }
}
