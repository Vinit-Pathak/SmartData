﻿using Core.Interface;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Core.App.Appointment.Provider.Command
{
    public class CreateProviderAppointmentCommand : IRequest<AppResponse<object>>
    {
        public ProviderAppointmentDto ProviderAppointmentDto { get; set; }
    }

    public class CreateProviderAppointmentCommandHandler : IRequestHandler<CreateProviderAppointmentCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;

        public CreateProviderAppointmentCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<AppResponse<object>> Handle(CreateProviderAppointmentCommand request, CancellationToken cancellationToken)
        {

            var existingAppointment = await _context.Set<Domain.Models.Appointment.Appointment>()
                                .FirstOrDefaultAsync(a =>
                                    a.ProviderId == request.ProviderAppointmentDto.ProviderId &&
                                    a.PatientId == request.ProviderAppointmentDto.PatientId &&
                                    a.AppointmentDate == request.ProviderAppointmentDto.AppointmentDate &&
                                    a.AppointmentTime == request.ProviderAppointmentDto.AppointmentTime);

            if (existingAppointment != null)
            {
                return AppResponse.Fail<object>(
                    message: "An appointment already exists for the given time",
                    statusCode: HttpStatusCodes.Conflict
                );
            }

            var patient = await _context.Set<Domain.Models.User.User>()
                 .FirstOrDefaultAsync(u => u.UserId == request.ProviderAppointmentDto.PatientId);

            if (patient == null)
            {
                return AppResponse.Fail<object>(
                    message: "Patient not found",
                    statusCode: HttpStatusCodes.NotFound
                );
            }
            var provider = await _context.Set<Domain.Models.User.User>()
                 .FirstOrDefaultAsync(u => u.UserId == request.ProviderAppointmentDto.ProviderId);

            if (provider == null)
            {
                return AppResponse.Fail<object>(
                    message: "Provider not found",
                    statusCode: HttpStatusCodes.NotFound
                );
            }

            if (request.ProviderAppointmentDto.AppointmentDate < DateTime.Today || (request.ProviderAppointmentDto.AppointmentDate == DateTime.Today && request.ProviderAppointmentDto.AppointmentTime <= DateTime.Now.TimeOfDay))
            {
                return AppResponse.Fail<object>(
                    message: "Appointment date should be greater than today",
                    statusCode: HttpStatusCodes.BadRequest
                );
            }


            var appointment = new Domain.Models.Appointment.Appointment
            {
                PatientId = request.ProviderAppointmentDto.PatientId,
                ProviderId = request.ProviderAppointmentDto.ProviderId,
                AppointmentDate = request.ProviderAppointmentDto.AppointmentDate,
                AppointmentTime = request.ProviderAppointmentDto.AppointmentTime,
                AppointmentStatus = "Scheduled",
                ChiefComplaint = request.ProviderAppointmentDto.ChiefComplaint,
                SpecialisationId = (int)provider.SpecializationId,
                Fee = (float)provider.VisitingCharge,
            };

            await _context.Set<Domain.Models.Appointment.Appointment>().AddAsync(appointment);
            await _context.SaveChangesAsync();

            await _emailService.SendEmailAsync(patient.Email, "Appointment Created", $"Your appointment with {provider.FirstName} {provider.LastName} has been scheduled for {appointment.AppointmentDate} at {appointment.AppointmentTime}.");

            await _emailService.SendEmailAsync(provider.Email, "Appointment Created", $"You have an appointment with {patient.FirstName} {patient.LastName} has been scheduled for {appointment.AppointmentDate} at {appointment.AppointmentTime}.");

            return AppResponse.Success<object>(message: "Appointment created successfully", statusCode: HttpStatusCodes.OK, data: appointment);
        }
    }
}
