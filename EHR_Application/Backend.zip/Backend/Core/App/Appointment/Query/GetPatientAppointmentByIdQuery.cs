﻿using Core.Interface;
using Dapper;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Query
{
    public class GetPatientAppointmentByIdQuery : IRequest<AppResponse<object>>
    {
        public int Id { get; set; }
    }

    public class GetPatientAppointmentByIdQueryHandler : IRequestHandler<GetPatientAppointmentByIdQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetPatientAppointmentByIdQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<AppResponse<object>> Handle(GetPatientAppointmentByIdQuery request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);
            var query = @"
                        select a.* ,
                        CONCAT(pat.FirstName, ' ', pat.LastName) AS PatientName,
                        CONCAT(prov.FirstName, ' ', prov.LastName) AS ProviderName,
	                        sd.SpecializationName
                        from Appointments a
                        left join Users pat on pat.UserId = a.PatientId
                        left join Users prov on prov.UserId=a.ProviderId
                        left join Specializations sd on sd.SpecializationId =prov.SpecializationId
                        where a.PatientId = @Id or a.ProviderId = @Id                        
                        "
            ;

            var parameter = new { Id = request.Id };
            var result = await connection.QueryAsync<AppointmentDto>(query, parameter);


            if (result == null)
            {
                return AppResponse.Fail<object>(message: "Data not found", statusCode: HttpStatusCodes.NotFound);
            }

            return AppResponse.Success<object>(message: "Appointments List", statusCode: HttpStatusCodes.OK, data: result);
        }
    }
}
