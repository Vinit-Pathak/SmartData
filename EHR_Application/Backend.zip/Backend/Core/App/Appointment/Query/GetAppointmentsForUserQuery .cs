﻿//using Core.Interface;
//using Domain.ModelDto.Appointment;
//using MediatR;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Core.App.Appointment.Query
//{
//    public class GetAppointmentsForUserQuery: IRequest<List<AppointmentDto>>
//    {
//        public int UserId { get; set; }
//        public int UserTypeId { get; set; }
//    }

//    public class GetAppointmentsForUserQueryHandler : IRequestHandler<GetAppointmentsForUserQuery, List<AppointmentDto>>
//    {
//        private readonly IAppDbContext _context;

//        public GetAppointmentsForUserQueryHandler(IAppDbContext context)
//        {
//            _context = context;
//        }
//        public async Task<List<AppointmentDto>> Handle(GetAppointmentsForUserQuery request, CancellationToken cancellationToken)
//        {
//            var appointmentsQuery = _context.Set<Domain.Models.Appointment.Appointment>().AsQueryable();
//            if(request.UserTypeId == 1)
//            {
//                appointmentsQuery = appointmentsQuery.Where(x => x.PatientId == request.UserId);
//            }
//            else if (request.UserTypeId == 2)
//            {
//                appointmentsQuery = appointmentsQuery.Where(x => x.ProviderId == request.UserId);
//            }

//            return await appointmentsQuery
//                .Select(a => new AppointmentDto
//                {
//                    Id = a.Id,
//                    AppointmentDate = a.AppointmentDate,
//                    AppointmentTime = a.AppointmentTime,
//                    ChiefComplaint = a.ChiefComplaint,
//                    Fee = a.Fee,
//                    AppointmentStatus = a.AppointmentStatus,
//                    PatientName = _context.Set<Domain.Models.User.User>().Where(u => u.UserId == a.PatientId).Select(u => u.FirstName + " " + u.LastName).FirstOrDefault(),
//                    ProviderName = _context.Set<Domain.Models.User.User>().Where(u => u.UserId == a.ProviderId).Select(u => u.FirstName + " " + u.LastName).FirstOrDefault()


//                }).ToListAsync(cancellationToken);
//        }
//    }
//}
