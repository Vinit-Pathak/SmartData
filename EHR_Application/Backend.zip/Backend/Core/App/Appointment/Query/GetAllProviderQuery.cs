﻿using Core.Interface;
using Dapper;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Query
{
    public class GetAllProviderQuery : IRequest<AppResponse<object>>
    {
        public int UserTypeId { get; set; }
    }

    public class GetAllProviderQueryHandler : IRequestHandler<GetAllProviderQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetAllProviderQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<AppResponse<object>> Handle(GetAllProviderQuery request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);
            var query = "SELECT * FROM Users WHERE UserTypeId = 2 AND IsDeleted = 0";
            var provider = await connection.QueryAsync<Domain.Models.User.User>(query);

            if (query == null)
            {
                return AppResponse.Fail<object>(message: "No provider found", statusCode: HttpStatusCodes.NotFound);
            }

            return AppResponse.Success<object>(data: provider, message: "All Providers found", statusCode: HttpStatusCodes.OK);

        }
    }
}
