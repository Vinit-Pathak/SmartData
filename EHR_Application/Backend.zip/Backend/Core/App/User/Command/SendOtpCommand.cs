﻿using Core.Interface;
using Domain.ModelDto.Response;
using Domain.Models.Otp;
using Domain.Models.User;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Command
{
    public class SendOtpCommand:IRequest<AppResponseDto>
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class SendOtpCommandHandler : IRequestHandler<SendOtpCommand, AppResponseDto>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
        public SendOtpCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<AppResponseDto> Handle(SendOtpCommand request, CancellationToken cancellationToken)
        {
            var username = request.Username;
            var password = request.Password;

            var userExists = await _context.Set<Domain.Models.User.User>()
                                .FirstOrDefaultAsync(x => x.UserName == username);

            if(userExists == null || !BCrypt.Net.BCrypt.Verify(password, userExists.Password))
            {
                return new AppResponseDto
                {
                    StatusCode = 401,
                    Message = "Invalid Credentials"
                };
            }

            var otp = new Random().Next(100000, 999999).ToString();
            var existingOtps = await _context.Set<Otp>()
                .Where(o => o.UserName.ToLower() == userExists.UserName.ToLower())
                .ToListAsync(cancellationToken);

            if (existingOtps.Any())
            {
                _context.Set<Otp>().RemoveRange(existingOtps);
            }

            var otpEntry = new Otp
            {
                UserName = userExists.UserName,
                Code = otp,
                Expiration = DateTime.Now.AddMinutes(5)
            };

            await _context.Set<Otp>().AddAsync(otpEntry, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            await _emailService.SendEmailAsync(userExists.Email, "Your OTP Code", $"Your OTP is {otp}");

            return new AppResponseDto
            {
                StatusCode = 200,
                Message = "Otp Send Successfully..."
            };
        }
    }
}
