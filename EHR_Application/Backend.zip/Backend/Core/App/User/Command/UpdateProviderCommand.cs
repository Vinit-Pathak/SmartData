﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Core.Interface;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.Extensions.Configuration;

namespace Core.App.User.Command
{
    public class UpdateProviderCommand : IRequest<AppResponse<object>>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
        public Domain.ModelDto.User.UpdateProviderDto UpdateProviderDto { get; set; }
    }


    public class UpdateProviderCommandHandler : IRequestHandler<UpdateProviderCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ehrapplication";
        private readonly string _folderName = "user-profile-images";

        public UpdateProviderCommandHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
        }
        public async Task<AppResponse<object>> Handle(UpdateProviderCommand request, CancellationToken cancellationToken)
        {
            var id = request.UpdateProviderDto.UserId;
            var provider = await _context.Set<Domain.Models.User.User>().FindAsync(id);

            if (provider == null)
            {
                return AppResponse.Fail<object>(message: "Provider not found", statusCode: HttpStatusCodes.NotFound);
            }

            var imageUrl = string.Empty;

            if (request.FileName != null)
            {
                // STORING IMAGES
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName) // Get MIME type dynamically
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                imageUrl = blobClient.Uri.ToString();
            }


            provider.FirstName = request.UpdateProviderDto.FirstName;
            provider.LastName = request.UpdateProviderDto.LastName;
            provider.Mobile = request.UpdateProviderDto.Mobile;
            provider.DateOfBirth = request.UpdateProviderDto.DateOfBirth;
            provider.Gender = request.UpdateProviderDto.Gender;
            provider.BloodGroup = request.UpdateProviderDto.BloodGroup;
            if (!string.IsNullOrEmpty(imageUrl))
            {
                provider.ProfileImageUrl = imageUrl;
            }
            provider.Address = request.UpdateProviderDto.Address;
            provider.City = request.UpdateProviderDto.City;
            provider.State = request.UpdateProviderDto.State;
            provider.Country = request.UpdateProviderDto.Country;
            provider.PinCode = request.UpdateProviderDto.PinCode;
            provider.Qualification = request.UpdateProviderDto.Qualification;
            provider.SpecializationId = request.UpdateProviderDto.SpecializationId;
            provider.RegistrationNumber = request.UpdateProviderDto.RegistrationNumber;
            provider.VisitingCharge = request.UpdateProviderDto.VisitingCharge;


            await _context.SaveChangesAsync(cancellationToken);
            return AppResponse.Success<object>(data: provider, message: "Provider updated successfully", statusCode: HttpStatusCodes.OK);

        }

        private string GetContentType(string fileName)
        {
            var extension = System.IO.Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream",
            };
        }
    }
}
