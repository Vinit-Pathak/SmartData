﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Core.Interface;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mapster;

namespace Core.App.User.Command
{
    public class UpdateUserCommand : IRequest<AppResponse<object>>
    {
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
        public Domain.ModelDto.User.UpdateUserDto UpdateUserDto { get; set; }
    }

    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ehrapplication";
        private readonly string _folderName = "user-profile-images";

        public UpdateUserCommandHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
        }
        public async Task<AppResponse<object>> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var id = request.UpdateUserDto.UserId;
            var user = await _context.Set<Domain.Models.User.User>().FindAsync(id);

            if (user == null)
            {
                return AppResponse.Fail<object>(message: "Patient not found", statusCode: HttpStatusCodes.NotFound);
            }

            var imageUrl = string.Empty;

            if (request.FileName != null)
            {
                // STORING IMAGES
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName) // Get MIME type dynamically
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                imageUrl = blobClient.Uri.ToString();
            }


                user.FirstName = request.UpdateUserDto.FirstName;
                user.LastName = request.UpdateUserDto.LastName;
                user.Mobile = request.UpdateUserDto.Mobile;
                user.DateOfBirth = request.UpdateUserDto.DateOfBirth;
                user.Gender = request.UpdateUserDto.Gender;
                user.BloodGroup = request.UpdateUserDto.BloodGroup;
                if (!string.IsNullOrEmpty(imageUrl))
                {
                    user.ProfileImageUrl = imageUrl;
                }
                user.Address = request.UpdateUserDto.Address;
                user.City = request.UpdateUserDto.City;
                user.State = request.UpdateUserDto.State;
                user.Country = request.UpdateUserDto.Country;
                user.PinCode = request.UpdateUserDto.PinCode;
                //user.Qualification = request.UpdateUserDto.Qualification;
                //user.SpecializationId = request.UpdateUserDto.SpecializationId ;
                //user.RegistrationNumber = request.UpdateUserDto.RegistrationNumber;
                //user.VisitingCharge = request.UpdateUserDto.VisitingCharge ;

                await _context.SaveChangesAsync(cancellationToken); 
                //var providerData = user.Adapt<Domain.ModelDto.User.RegistrationDto>();

                return AppResponse.Success<object>(data: user, message: "User updated successfully", statusCode: HttpStatusCodes.OK);

            
        }
            private string GetContentType(string fileName)
            {
            var extension = System.IO.Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream",
            };
        }
    }
}
