﻿using Core.Interface;
using Domain.ModelDto.Response;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Command
{
    public class ChangePasswordCommand: IRequest<AppResponseDto>
    {
        public ChangePasswordDto ChangePasswordDto { get; set; }
    }

    public class ChangePasswordCommandHandler : IRequestHandler<ChangePasswordCommand, AppResponseDto>
    {
        private readonly IAppDbContext _context;

        public ChangePasswordCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<AppResponseDto> Handle(ChangePasswordCommand request, CancellationToken cancellationToken)
        {
            var model = request.ChangePasswordDto;
            var user = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(x => x.UserName == model.UserName);
            if (user == null)
            {
                return new AppResponseDto
                {
                    StatusCode = 404,
                    Message = "User not found"
                };
            }

            user.Password = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
            await _context.SaveChangesAsync(cancellationToken);

            return new AppResponseDto
            {
                StatusCode = 200,
                Message = "Password changed successfully"
            };
        }
    }
}
