﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Core.Interface;
using Domain.ModelDto.Response;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PasswordGenerator;

namespace Core.App.User.Command
{
    public class CreateUserCommand : IRequest<AppResponse<object>>
    {
        public RegistrationDto RegistrationDto { get; set; }
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
    }

    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
        private readonly string _connectionString;
        private readonly string _containerName = "ehrapplication";
        private readonly string _folderName = "user-profile-images";

        public CreateUserCommandHandler(IAppDbContext context, IEmailService emailService, IConfiguration configuration)
        {
            _context = context;
            _emailService = emailService;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
        }
        public async Task<AppResponse<object>> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            var user = request.RegistrationDto;
            string username = "";
            if (user == null)
            {
                //return new AppResponseDto
                //{
                //    StatusCode = 404,
                //    Message = "user cannot be null",
                //};
                return AppResponse.Fail<object>(message: "User cannot be null", statusCode: HttpStatusCodes.NotFound);
            }

            var userExists = await _context.Set<Domain.Models.User.User>()
                                              .Where(x => x.Email == user.Email)
                                              .FirstOrDefaultAsync(cancellationToken);
            if (userExists != null)
            {
                //return new AppResponseDto
                //{
                //    StatusCode = 409,
                //    Message = "user with this email already exists"
                //};
                return AppResponse.Fail<object>(message: "User with this email already exists", statusCode: HttpStatusCodes.Conflict);
            }

            string newDOB = user.DateOfBirth.ToString("ddMMyy");
            if (user.UserTypeId == 1)
            {
                username = $"PT_{user.FirstName.ToUpper()}{user.LastName[0].ToString().ToUpper()}{newDOB}";

            }
            else
            {
                username = $"PR_{user.FirstName.ToUpper()}{user.LastName[0].ToString().ToUpper()}{newDOB}";
            }
            var passwordGenerator = new Password(true, true, true, true, 8);
            string password = passwordGenerator.Next();
            password = password.Replace("\\", "#");

            if (userExists != null && userExists.UserName == username)
            {
                //return new AppResponseDto
                //{
                //    StatusCode = 409,
                //    Message = "User with this username already exists"
                //};
                return AppResponse.Fail<object>(message: "User with this username already exists", statusCode: HttpStatusCodes.Conflict);
            }

            var blobServiceClient = new BlobServiceClient(_connectionString);
            var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

            var blobHttpHeaders = new BlobHttpHeaders
            {
                ContentType = GetContentType(request.FileName) // Get MIME type dynamically
            };

            await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
            {
                HttpHeaders = blobHttpHeaders
            });
            var imageUrl = blobClient.Uri.ToString();

            var newPatient = new Domain.Models.User.User
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                DateOfBirth = user.DateOfBirth,
                Mobile = user.Mobile,
                Email = user.Email,
                UserName = username,
                Password = BCrypt.Net.BCrypt.HashPassword(password),
                Gender = user.Gender,
                BloodGroup = user.BloodGroup,
                ProfileImageUrl = imageUrl,
                Address = user.Address,
                City = user.City,
                State = user.State,
                Country = user.Country,
                PinCode = user.PinCode,
                UserTypeId = user.UserTypeId,
                Qualification = user.Qualification ?? null,
                SpecializationId = user.SpecializationId ?? null,
                RegistrationNumber = user.RegistrationNumber ?? null,
                VisitingCharge = user.VisitingCharge ?? null,
                IsDeleted = false
            };

            await _context.Set<Domain.Models.User.User>().AddAsync(newPatient);
            await _context.SaveChangesAsync();

            await _emailService.SendEmailAsync(user.Email, "Welcome to EHR Application",
                    $"Your username is {username} and your password is {password}");

            return AppResponse.Success<object>(message: "User created successfully", statusCode: HttpStatusCodes.Created);
        }


        
        private static string GetContentType(string fileName)
        {
            return fileName.EndsWith(".jpg") || fileName.EndsWith(".jpeg") ? "image/jpeg" :
                   fileName.EndsWith(".png") ? "image/png" :
                   "application/octet-stream"; // Default fallback
        }
    }
}
