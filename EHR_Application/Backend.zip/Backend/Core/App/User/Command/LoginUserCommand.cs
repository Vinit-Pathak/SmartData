﻿using Core.Interface;
using Domain.ModelDto.Response;
using Domain.ModelDto.User;
using Domain.Models.Otp;
using Mapster;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Core.App.User.Command
{
    public class LoginUserCommand : IRequest<LoginResponseDto>
    {
        public LoginDto Login { get; set; }
    }

    public class LoginUserCommandHandler : IRequestHandler<LoginUserCommand, LoginResponseDto>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
        private readonly IConfiguration _configuration;

        public LoginUserCommandHandler(IAppDbContext context, IEmailService emailService, IConfiguration configuration)
        {
            _context = context;
            _emailService = emailService;
            _configuration = configuration;
        }

        public async Task<LoginResponseDto> Handle(LoginUserCommand request, CancellationToken cancellationToken)
        {
            var user = request.Login;
            if (user == null)
            {
                return new LoginResponseDto
                {
                    StatusCode = 404,
                    Message = "Fields cannot be null"
                };
            }

            var userExists = await _context.Set<Domain.Models.User.User>()
                                .FirstOrDefaultAsync(x => x.UserName == user.UserName);

            if (userExists == null || !BCrypt.Net.BCrypt.Verify(user.Password, userExists.Password))
            {
                return new LoginResponseDto
                {
                    StatusCode = 401,
                    Message = "Invalid Credentials",
                    IsSuccess = false
                };
            }

            var otp = await _context.Set<Otp>()
                .FirstOrDefaultAsync(x => x.UserName == user.UserName && x.Code == user.Otp);

            if (otp == null || otp.Expiration < DateTime.Now || otp.Code != user.Otp)
            {
                return new LoginResponseDto
                {
                    StatusCode = 401,
                    Message = "Invalid Otp",
                    IsSuccess = false
                };
            }

            _context.Set<Otp>().Remove(otp);
            await _context.SaveChangesAsync(cancellationToken);

            var userType = await _context.Set<Domain.Models.User.UserType>()
                                .FirstOrDefaultAsync(x => x.UserTypeId == userExists.UserTypeId
                                , cancellationToken);
            var claims = new[]
            {
                new Claim("Id", userExists.UserId.ToString()),
                new Claim("UserName", userExists.UserName),
                new Claim("Email", userExists.Email),
                new Claim(ClaimTypes.Role, userType.Name)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"] ?? string.Empty));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(60),
                signingCredentials: creds
            );

            var jwt = new JwtSecurityTokenHandler().WriteToken(token);
            var userData = userExists.Adapt<UserDto>();


            return new LoginResponseDto
            {
                IsSuccess = true,
                StatusCode = 200,
                Message = "Login Successfull",
                Token = jwt,
                Data = userData,
                Expiration = token.ValidTo
            };

        }
    }
}
