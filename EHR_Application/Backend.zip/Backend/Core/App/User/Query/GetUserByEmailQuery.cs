﻿using Core.Interface;
using Dapper;
using Domain.ModelDto.Response;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Query
{
    public class GetUserByEmailQuery : IRequest<AppResponse<object>>
    {
        public string Email { get; set; } = string.Empty;
    }

    public class GetUserByEmailQueryHandler : IRequestHandler<GetUserByEmailQuery, AppResponse<object>>
    {
        private readonly IConfiguration _configuration;

        public GetUserByEmailQueryHandler( IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<AppResponse<object>> Handle(GetUserByEmailQuery request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);

            const string query = @"
                                        SELECT 
                                        u.UserId,
                                        u.FirstName,
                                        u.LastName,
                                        u.DateOfBirth,
                                        u.Mobile,
                                        u.Email,
                                        u.UserName,
                                        u.Gender,
                                        u.BloodGroup,
                                        u.ProfileImageUrl,
                                        u.UserTypeId,
                                        u.Address,
                                        u.City,
                                        u.PinCode,
                                        c.Name AS CountryName,  
                                        st.Name AS StateName,  
                                        u.Qualification,
                                        sp.SpecializationName AS SpecialisationName,  
                                        sp.SpecializationId,
                                        u.RegistrationNumber,
                                        u.VisitingCharge,
                                        u.IsDeleted
                                        FROM Users u
                                        LEFT JOIN Countries c ON u.Country = c.CountryId 
                                        LEFT JOIN States st ON u.State = st.StateId 
                                        LEFT JOIN Specializations sp ON u.SpecializationId = sp.SpecializationId
                                        WHERE u.Email = @Email AND u.IsDeleted = 0";

            var parameter = new { Email = request.Email };
            var userData = await connection.QueryAsync<UserDto>(query, parameter);



            //return new AppResponseDto
            //{
            //    StatusCode = userData != null ? 200 : 404,
            //    Message = userData != null ? "User data found" : "User data not found",
            //    Data = userData
            //};
            return AppResponse.Success<object>(data: userData,
                                               message: userData != null ? "User data found" : "User data not found",
                                               statusCode: userData != null ? HttpStatusCodes.OK : HttpStatusCodes.NotFound);
        }
    }
}
