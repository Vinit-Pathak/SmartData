﻿using Core.Interface;
using Dapper;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Query
{
    public class GetUserDetailsByAppointmentId : IRequest<AppResponse<object>>
    {
        public int AppointmentId { get; set; }
    }

    public class GetUserDetailsByAppointmentIdHandler : IRequestHandler<GetUserDetailsByAppointmentId, AppResponse<object>>
    {
        private readonly IConfiguration _configuration;

        public GetUserDetailsByAppointmentIdHandler(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<AppResponse<object>> Handle(GetUserDetailsByAppointmentId request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);

            const string query = @"select	Appointments.*, 
			                        users.FirstName, 
			                        users.LastName, 
			                        users.BloodGroup,  
			                        users.ProfileImageUrl, 
			                        users.DateOfBirth, 
			                        users.Gender
                                    from Appointments
                                    left join users on Appointments.PatientId = users.UserId
                                    where Appointments.AppointmentId = @AppointmentId AND users.IsDeleted = 0";

            var parameter = new { request.AppointmentId };
            var result = await connection.QueryAsync<object>(query, parameter);

            return AppResponse.Success<object>(data: result, message: "User details fetched successfully based on Appointment Id", statusCode: HttpStatusCodes.OK);


        }
    }
}
