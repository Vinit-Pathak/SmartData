﻿using Core.App.User.Command;
using Core.App.User.Query;
using Dapper;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public AuthController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

        [HttpPost("registration")]
        public async Task <IActionResult> UserRegister(RegistrationDto model)
        {
            using (var stream = model.File.OpenReadStream())
            {
                var command = new CreateUserCommand
                {
                    FileStream = stream,
                    FileName = model.File.FileName,
                    RegistrationDto = model
                };

                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return Conflict(result);
                }
                return Ok(result);
            }
        }


        [HttpPost("login")]
        public async Task<IActionResult> UserLogin(LoginDto model)
        {
            var result = await _mediator.Send(new LoginUserCommand { Login = model });
            if (!result.IsSuccess)
            {
                return Unauthorized(result);
            }
            return Ok(result);
        }


        [HttpGet("sendOtp/{username}/{password}")]
        public async Task<IActionResult> SendOtp(string username, string password)
        {
            var result = await _mediator.Send(new SendOtpCommand { Username = username, Password = password });
            if (!result.IsSuccess)
            {
                return Unauthorized(result);
            }
            return Ok(result);
        }

        [HttpGet("forgotPassword")]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            var result = await _mediator.Send(new ForgetPasswordCommand { Email = email });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        

    }
}
