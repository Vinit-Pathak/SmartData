﻿using Core.App.CountryState.Country;
using Core.App.CountryState.State;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryStateController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CountryStateController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet("getAllCountry")]
        public async Task<IActionResult> GetAllCountry()
        {
            var result = await _mediator.Send(new GetAllCountryQuery());
            return Ok(result);
        }

        [HttpGet("all-state")]
        public async Task<IActionResult> GetAllState()
        {
            var result = await _mediator.Send(new GetAllStateQuery());
            return Ok(result);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAllStateByCountryId(int id)
        {
            var allStateByCountryId = await _mediator.Send(new GetAllStateByCountryIdQuery { CountryId = id });
            return Ok(allStateByCountryId);
        }
    }
}
