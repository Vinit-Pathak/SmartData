﻿using Core.App.User.Command;
using Core.App.User.Query;
using Dapper;
using Domain.ModelDto.User;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public UserController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }


        [HttpGet("getAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = "SELECT * FROM Users WHERE IsDeleted = 0";
                var users = await connection.QueryAsync<UserDto>(query);
                if (users == null)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "No users found"
                    });
                }
                return Ok(users.ToList());
            }
        }

        [HttpGet("getUserById/{id}")]
        public async Task<IActionResult> GetUserById(int id)
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = "SELECT * FROM Users WHERE UserId = @UserId AND IsDeleted = 0";
                var user = await connection.QuerySingleOrDefaultAsync<Domain.Models.User.User>(query, new { UserId = id });
                if (user == null)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "User not found"
                    });
                }
                return Ok(new
                {
                    statusCode = 200,
                    data = user
                });
            }
        }

        [HttpGet("getUserByEmail/{email}")]
        public async Task<IActionResult> GetUserByEmail(string email)
        {
            var result = await _mediator.Send(new GetUserByEmailQuery { Email = email });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpGet("getUserDetailsByAppointmentId/{appointmentId}")]
        public async Task<IActionResult> GetUserDetailsByAppointmentId(int appointmentId)
        {
            var result = await _mediator.Send(new GetUserDetailsByAppointmentId { AppointmentId = appointmentId });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpPost("changePassword")]
        public async Task<IActionResult> ChangePassword(ChangePasswordDto model)
        {
            var result = await _mediator.Send(new ChangePasswordCommand { ChangePasswordDto = model });
            if (!result.IsSuccess)
            {
                return Unauthorized(result);
            }
            return Ok(result);
        }

        [HttpPut("updateUser")]
        public async Task<IActionResult> UpdateUserById(UpdateUserDto user)
        {
            if(user.File == null)
            {
                var command = new UpdateUserCommand
                {
                    FileStream = null,
                    FileName = null,
                    UpdateUserDto = user
                };
                var result = await _mediator.Send(command);
                if(!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }

            using (var stream = user.File.OpenReadStream())
            {
                var command = new UpdateUserCommand
                {
                    FileStream = stream,
                    FileName = user.File.FileName,
                    UpdateUserDto = user
                };

                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }
        }

        [HttpPut("updateProvider")]
        public async Task<IActionResult> UpdateProviderById(UpdateProviderDto provider)
        {
            if (provider.File == null)
            {
                var command = new UpdateProviderCommand
                {
                    FileStream = null,
                    FileName = null,
                    UpdateProviderDto = provider
                };
                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }

            using (var stream = provider.File.OpenReadStream())
            {
                var command = new UpdateProviderCommand
                {
                    FileStream = stream,
                    FileName = provider.File.FileName,
                    UpdateProviderDto = provider
                };

                var result = await _mediator.Send(command);
                if (!result.IsSuccess)
                {
                    return NotFound(result);
                }
                return Ok(result);
            }
        }
    }
}
