﻿using Core.Interface;
using Dapper;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public AppointmentController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

        [HttpGet("getAllSpecialisation")]
        public async Task<IActionResult> GetAllSpecialisation()
        {
            //var connection = _context.GetConnection();
            //var query = "SELECT * FROM Specializations";
            //await connection.QueryAsync<Domain.Models.Specialisation.Specialization>(query);
            //return Ok();

            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = "SELECT * FROM Specializations";
                var specializations = await connection.QueryAsync<Domain.Models.Specialisation.Specialization>(query);
                if (specializations == null)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "Data not found"
                    });
                }
                return Ok(new
                {
                    statusCode = 200,
                    data = specializations
                });
            }

        }
    }
}
