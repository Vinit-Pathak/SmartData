export interface Grocery{
    id:number;
    name:string;
    type:string;
}