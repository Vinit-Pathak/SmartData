import { Component } from '@angular/core';

@Component({
  selector: 'app-operaters',
  standalone: true,
  imports: [],
  templateUrl: './operaters.component.html',
  styleUrl: './operaters.component.scss'
})
export class OperatersComponent {

}
