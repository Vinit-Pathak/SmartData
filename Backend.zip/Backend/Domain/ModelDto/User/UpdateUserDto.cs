﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ModelDto.User
{
    public class UpdateUserDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Mobile { get; set; }
        public string Gender { get; set; }
        public string BloodGroup { get; set; }
        public IFormFile? File { get; set; }

        public string Address { get; set; }
        public string City { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int PinCode { get; set; }

        //public string? Qualification { get; set; }
        //public int? SpecializationId { get; set; }
        //public string? RegistrationNumber { get; set; }
        //public float? VisitingCharge { get; set; }
    }
}
