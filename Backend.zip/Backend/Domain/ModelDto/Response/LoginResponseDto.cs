﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.ModelDto.Response
{
    public sealed class LoginResponseDto
    {
        public bool IsSuccess { get; set; } = true;
        public string Message { get; set; } = string.Empty;
        public int StatusCode { get; set; }
        public string Token { get; set; }
        public object Data { get; set; }
        public DateTime Expiration { get; set; }
    }
}
