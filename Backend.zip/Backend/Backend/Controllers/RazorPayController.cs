﻿using Core.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RazorPayController : ControllerBase
    {
        private readonly IRazorpayService _razorpayService;

        public RazorPayController(IRazorpayService razorpayService)
        {
            _razorpayService = razorpayService;
        }

        [HttpPost("createOrder")]
        public async Task<IActionResult> CreateOrder([FromBody] decimal amount)
        {
            if (amount == null || amount <= 0)
            {
                return BadRequest("Invalid payment request.");
            }

            try
            {
                var order = await _razorpayService.CreateOrderAsync(amount);
                // iterate order which is an object


                if (order != null)
                {
                    return Ok(order);
                }
                else
                {
                    return NotFound("Order could not be created.");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("verify-payment")]
        public async Task<IActionResult> VerifyPayment(Domain.ModelDto.Payment.PaymentVerificationDto request)
        {
            var payment = await _razorpayService.VerifyPaymentAsync(request.PaymentId, request.OrderId);
            if (payment != null)
            {
                return Ok(payment);
            }
            return BadRequest("Payment verification failed");
        }
    }
}
