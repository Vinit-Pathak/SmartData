﻿using Core.App.Appointment.Patient;
using Core.App.Appointment.Patient.Command;
using Core.App.Appointment.Patient.Query;
using Core.App.Appointment.Provider.Command;
using Core.App.Appointment.Provider.Query;
using Core.Interface;
using Dapper;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.User;
using Infrastructure.Service;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;
        private readonly StripeService _stripeService;

        public AppointmentController(IMediator mediator, IConfiguration configuration, StripeService stripeService)
        {
            _mediator = mediator;
            _configuration = configuration;
            _stripeService = stripeService;
        }


        [HttpGet("getAllPatients")]
        public async Task<IActionResult> GetAllPatients()
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = "SELECT * FROM Users WHERE UserTypeId = 1 AND IsDeleted = 0";
                var users = await connection.QueryAsync<UserDto>(query);
                if (users == null)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "No users found"
                    });
                }
                return Ok(users.ToList());
            }
        }

        [HttpGet("getAllSpecialisation")]
        public async Task<IActionResult> GetAllSpecialisation()
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = "SELECT * FROM Specializations";
                var specializations = await connection.QueryAsync<Domain.Models.Specialisation.Specialization>(query);
                if (specializations == null)
                {
                    return NotFound(new
                    {
                        statusCode = 404,
                        message = "Data not found"
                    });
                }
                return Ok(new
                {
                    statusCode = 200,
                    data = specializations
                });
            }

        }

        [HttpGet("getProviderBySpecialisation/{specialisationId}")]
        public async Task<IActionResult> GetProviderBySpecialisation(int specialisationId)
        {
            var result = await _mediator.Send(new GetProviderBySpecialityQuery { SpecialisationId = specialisationId });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpGet("getAllProviders")]
        public async Task<IActionResult> GetAllProviders()
        {
            var result = await _mediator.Send(new GetAllProviderQuery ());
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpGet("getPatientAppointment/{userId}")]
        public async Task<IActionResult> GetPatientAppointment(int userId)
        {
            var result = await _mediator.Send(new GetPatientAppointmentByIdQuery { Id = userId });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpPost("patientAppointment")]
        public async Task<IActionResult> PatientAppointment(PatientAppointmentDto model)
        {
            var result = await _mediator.Send(new CreatePatientAppointmentCommand { PatientAppointmentDto = model });
            if (!result.IsSuccess)
            {
                return Conflict(result);
            }
            return Ok(result);
        }

        [HttpDelete("cancelPatientAppointment/{appointmentId}")]
        public async Task<IActionResult> CancelPatientAppointment(int appointmentId)
        {
            var result = await _mediator.Send(new CancelPatientAppointmentCommand { AppointmentId = appointmentId });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpPost("providerAppointment")]
        public async Task<IActionResult> ProviderAppointment(ProviderAppointmentDto model)
        {
            var result = await _mediator.Send(new CreateProviderAppointmentCommand { ProviderAppointmentDto = model });
            if (!result.IsSuccess)
            {
                return Conflict(result);
            }
            return Ok(result);
        }

        [HttpGet("getProviderAppointment/{userId}")]
        public async Task<IActionResult> GetProviderAppointment(int userId)
        {
            var result = await _mediator.Send(new GetUpcomingAppointmentsQuery { ProviderId = userId });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpPut("updatePatientAppointment")]
        public async Task<IActionResult> UpdatePatientAppointment(UpdatePatientAppointmentDto model)
        {
            var result = await _mediator.Send(new UpdatePatientAppointment { UpdatePatientAppointmentDto = model });
            if (!result.IsSuccess)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [HttpPost("addSoapNotes")]
        public async Task<IActionResult> AddSoapNotes(SOAPNotesDto model)
        {
            var result = await _mediator.Send(new AddSoapNotesCommand { SOAPNotesDto = model });
            if (!result.IsSuccess)
            {
                return Conflict(result);
            }
            return Ok(result);
        }


        [HttpPost("create-payment-intent")]
        public async Task<IActionResult> CreatePaymentIntent([FromBody] CreatePaymentRequest request)
        {
            var paymentIntentClientSecret = await _stripeService.CreatePaymentIntent(request.Amount);
            return Ok(new { clientSecret = paymentIntentClientSecret });
        }

    }
}
