﻿using Microsoft.Extensions.Configuration;
using Stripe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Service
{
    public class StripeService
    {
        private readonly IConfiguration _configuration;
        private readonly string _secretKey;

        public StripeService(IConfiguration configuration)
        {
            _configuration = configuration;
            _secretKey = _configuration.GetValue<string>("Stripe:SecretKey");
            StripeConfiguration.ApiKey = _secretKey;
        }

        public async Task<string> CreatePaymentIntent(float amount)
        {
            var paymentIntentService = new PaymentIntentService();
            var paymentIntentCreateOptions = new PaymentIntentCreateOptions
            {
                Amount = (long)(amount * 100),
                Currency = "usd",
                PaymentMethodTypes = new List<string> { "card" },
            };

            var paymentIntent = await paymentIntentService.CreateAsync(paymentIntentCreateOptions);
            return paymentIntent.ClientSecret;
        }
    }

}
