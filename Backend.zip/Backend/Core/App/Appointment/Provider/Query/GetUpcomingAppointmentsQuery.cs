﻿using Core.Interface;
using Dapper;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Provider.Query
{
    public class GetUpcomingAppointmentsQuery: IRequest<AppResponse<object>>
    {
        public int ProviderId { get; set; }
    }

    public class GetUpcomingAppointmentsQueryHandler : IRequestHandler<GetUpcomingAppointmentsQuery, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetUpcomingAppointmentsQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<AppResponse<object>> Handle(GetUpcomingAppointmentsQuery request, CancellationToken cancellationToken)
        {

            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);
            var query = @"
                        SELECT 
                            a.*, 
                            CONCAT(pat.FirstName, ' ', pat.LastName) AS PatientName,
                            CONCAT(prov.FirstName, ' ', prov.LastName) AS ProviderName,
                            sd.SpecializationName
                        FROM 
                            Appointments a
                        LEFT JOIN 
                            Users pat ON pat.UserId = a.PatientId
                        LEFT JOIN 
                            Users prov ON prov.UserId = a.ProviderId
                        LEFT JOIN 
                            Specializations sd ON sd.SpecializationId = prov.SpecializationId
                        WHERE 
                            a.ProviderId = @ProviderId 
                            AND a.AppointmentStatus = 'Scheduled';
                        "
                                                    //AND a.AppointmentDate >= GETDATE()
            ;

            var parameter = new { request.ProviderId };
            var result = await connection.QueryAsync<AppointmentDto>(query, parameter);


            if (result == null)
            {
                return AppResponse.Fail<object>(message: "Data not found", statusCode: HttpStatusCodes.NotFound);
            }

            return AppResponse.Success<object>(message: "Appointments List", statusCode: HttpStatusCodes.OK, data: result);
        }
    }
}
