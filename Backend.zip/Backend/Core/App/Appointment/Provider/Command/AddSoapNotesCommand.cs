﻿using Core.Interface;
using Domain.ModelDto.Appointment;
using Domain.ModelDto.Response;
using Domain.Models.Appointment;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Appointment.Provider.Command
{
    public class AddSoapNotesCommand : IRequest<AppResponse<object>>
    {
        public SOAPNotesDto SOAPNotesDto { get; set; }
    }

    public class AddSoapNotesCommandHandler : IRequestHandler<AddSoapNotesCommand, AppResponse<object>>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;

        public AddSoapNotesCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<AppResponse<object>> Handle(AddSoapNotesCommand request, CancellationToken cancellationToken)
        {
            var appointment = await _context.Set<Domain.Models.Appointment.Appointment>()
                .FirstOrDefaultAsync(a => a.AppointmentId == request.SOAPNotesDto.AppointmentId, cancellationToken);

            if (appointment == null || appointment.AppointmentStatus != "Scheduled")
            {
                return AppResponse.Fail<object>(message: "Appointment not found or not scheduled", statusCode:HttpStatusCodes.NotFound);
            }

            bool soapNoteExists = await _context.Set<Domain.Models.Appointment.SOAPNotes>()
               .AnyAsync(s => s.AppointmentId == request.SOAPNotesDto.AppointmentId, cancellationToken);
            if(soapNoteExists)
            {
                return AppResponse.Fail<object>(message: "SOAP Notes already exists", statusCode: HttpStatusCodes.Conflict);
            }

            var newSoapNote = new Domain.Models.Appointment.SOAPNotes
            {
                AppointmentId = request.SOAPNotesDto.AppointmentId,
                Subjective = request.SOAPNotesDto.Subjective,
                Objective = request.SOAPNotesDto.Objective,
                Assessment = request.SOAPNotesDto.Assessment,
                Plan = request.SOAPNotesDto.Plan,
                CreatedAt = DateTime.Now
            };

            await _context.Set<Domain.Models.Appointment.SOAPNotes>().AddAsync(newSoapNote, cancellationToken);
            appointment.AppointmentStatus = "Completed";
            await _context.SaveChangesAsync(cancellationToken);

            var patient = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(u => u.UserId == appointment.PatientId, cancellationToken);
            if(patient == null)
            {
                return AppResponse.Fail<object>(message: "Patient not found", statusCode: HttpStatusCodes.NotFound);
            }

            var provider = await _context.Set<Domain.Models.User.User>()
                .FirstOrDefaultAsync(u => u.UserId == appointment.ProviderId, cancellationToken);
            if (provider == null)
            {
                return AppResponse.Fail<object>(message: "Provider not found", statusCode: HttpStatusCodes.NotFound);
            }

            await _emailService.SendEmailAsync(patient.Email,
                "Appointment Completed",
                GetPatientEmailBody(appointment.AppointmentId, patient.FirstName, newSoapNote.Subjective, newSoapNote.Objective, newSoapNote.Assessment, newSoapNote.Plan));

            await _emailService.SendEmailAsync(provider.Email,
                "Appointment Completed",
                GetProviderEmailBody(appointment.AppointmentId, provider.FirstName));


            return AppResponse.Success<object>(message: "SOAP Notes added successfully", statusCode: HttpStatusCodes.OK);
        }



        private static string GetPatientEmailBody(int appointmentId, string patientName, string subjective, string objective, string assessment, string plan)
        {
            return $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333333; }}
                        .container {{ margin: 0 auto; padding: 20px; border: 1px solid #dddddd; border-radius: 8px; background-color: #f9f9f9; max-width: 600px; }}
                        .header {{ font-size: 18px; font-weight: bold; color: #0056b3; }}
                        .footer {{ margin-top: 20px; font-size: 12px; color: #777777; }}
                        .details {{ margin-top: 10px; border-top: 1px solid #dddddd; padding-top: 10px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <p class='header'>Appointment Completed</p>
                        <p>Dear {patientName},</p>
                        <p>
                            Your recent appointment with ID <strong>{appointmentId}</strong> has been successfully completed. 
                            Below are the details of your SOAP notes:
                        </p>
                        <div class='details'>
                            <p><strong>Subjective:</strong> {subjective}</p>
                            <p><strong>Objective:</strong> {objective}</p>
                            <p><strong>Assessment:</strong> {assessment}</p>
                            <p><strong>Plan:</strong> {plan}</p>
                        </div>
                        <p>If you have any questions or need further assistance, please contact us.</p>
                        <p>Best regards,<br>The Appointment Team</p>
                        <div class='footer'>
                            <p>If you have any questions, please contact support at support@example.com.</p>
                        </div>
                    </div>
                </body>
                </html>";
        }


        private static string GetProviderEmailBody(int appointmentId, string providerName)
        {
            return $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333333; }}
                        .container {{ margin: 0 auto; padding: 20px; border: 1px solid #dddddd; border-radius: 8px; background-color: #f9f9f9; max-width: 600px; }}
                        .header {{ font-size: 18px; font-weight: bold; color: #0056b3; }}
                        .footer {{ margin-top: 20px; font-size: 12px; color: #777777; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <p class='header'>Appointment Completed</p>
                        <p>Dear {providerName},</p>
                        <p>
                            This is to inform you that the appointment with ID <strong>{appointmentId}</strong>
                            has been successfully completed.
                        </p>
                        <p>Thank you for your continued commitment and care for your patients.</p>
                        <p>Best regards,<br>The Appointment Team</p>
                        <div class='footer'>
                            <p>If you have any questions, please contact support at support@example.com.</p>
                        </div>
                    </div>
                </body>
                </html>";
        }
    }
}
