﻿using Core.App.Cart.Command;
using Core.App.Cart.Query;
using Core.Models.Cart;
using Dapper;
using Domain.Cart;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public CartController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            configuration = configuration;
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> AddToCart(AddToCartDto model)
        {
            var result = await _mediator.Send(new AddToCartCommand { AddToCart = model });
            return Ok(result);
           
        }


        [HttpPost("incrementcart")]
        public async Task<IActionResult> incrementQuantity(IncrementToCartDto incrementCartDto)
        {
            var cartQuanity = await _mediator.Send(new IncrementToCartCommand { IncrementToCart = incrementCartDto });
            return Ok(cartQuanity);
        }

        [HttpDelete("removeFromCart/{cartId}")]
        public async Task<IActionResult> RemoveFromCart(int cartId)
        {
           var cart = await _mediator.Send(new RemoveFromCartCommand { CartId = cartId });
            return Ok(cart);
        }


        [HttpGet("getCartDetails/{userId}")]
        public async Task<IActionResult> GetCartProduct(int userId)
        {
            var cartDetails = await _mediator.Send(new GetCartDetailsQuery(userId));
            if (cartDetails == null)
            {
                return NotFound(new { statusCode = 404, message = "No cart details found" });
            }
            return Ok(cartDetails);
        }



    }
}
