﻿using Core.App.Card;
using Core.App.Cart.Command;
using Core.App.Cart.Query;
using Core.Models;
using Core.Models.Cart;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public CartController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            configuration = configuration;
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> AddToCart(AddToCartDto model)
        {
            var result = await _mediator.Send(new AddToCartCommand { AddToCart = model });
            return Ok(result);

        }


        [HttpPost("incrementcart")]
        public async Task<IActionResult> incrementQuantity(IncrementToCartDto incrementCartDto)
        {
            var cartQuanity = await _mediator.Send(new IncrementToCartCommand { IncrementToCart = incrementCartDto });
            return Ok(cartQuanity);
        }

        [HttpDelete("removeFromCart/{cartId}")]
        public async Task<IActionResult> RemoveFromCart(int cartId)
        {
            var cart = await _mediator.Send(new RemoveFromCartCommand { CartId = cartId });
            return Ok(cart);
        }


        [HttpGet("getCartDetails/{userId}")]
        public async Task<IActionResult> GetCartProduct(int userId)
        {
            var cartDetails = await _mediator.Send(new GetCartDetailsQuery(userId));
            if (cartDetails == null)
            {
                return NotFound(new { statusCode = 404, message = "No cart details found" });
            }
            return Ok(cartDetails);
        }

        [HttpPost("decrementFromCart")]
        public async Task<IActionResult> DecrementFromCart(DecrementFromCartDto decrementFromCartDto)
        {
            var cartQuanity = await _mediator.Send(new DecrementFromCartCommand { DecrementFromCartDto = decrementFromCartDto });
            return Ok(cartQuanity);
        }

        [HttpPost("validateCard")]
        public async Task<IActionResult> ValidateCard(CardDto card)
        {
            var result = await _mediator.Send(new ValidateCardQuery { Card = card });
            if (!result)
            {
                return BadRequest(new { statusCode = 400, message = "Invalid card details" });
            }

            return Ok(new
            {
                statusCode = 200,
                message = "Card details are valid",
            });
        }


    }
}
