﻿using Core.App.Card;
using Core.App.Cart.Command;
using Core.App.Cart.Query;
using Core.App.Invoice;
using Core.Models;
using Core.Models.Cart;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CartController(IMediator mediator)
        {
            _mediator = mediator;
            
        }

        [HttpPost("addToCart")]
        public async Task<IActionResult> AddToCart(AddToCartDto model)
        {
            var result = await _mediator.Send(new AddToCartCommand { AddToCart = model });
            return Ok(result);

        }


        [HttpPost("incrementcart")]
        public async Task<IActionResult> incrementQuantity(IncrementToCartDto incrementCartDto)
        {
            var cartQuanity = await _mediator.Send(new IncrementToCartCommand { IncrementToCart = incrementCartDto });
            return Ok(cartQuanity);
        }

        [HttpDelete("removeFromCart/{cartId}")]
        public async Task<IActionResult> RemoveFromCart(int cartId)
        {
            var cart = await _mediator.Send(new RemoveFromCartCommand { CartId = cartId });
            return Ok(cart);
        }


        [HttpGet("getCartDetails/{userId}")]
        public async Task<IActionResult> GetCartProduct(int userId)
        {
            var cartDetails = await _mediator.Send(new GetCartDetailsQuery(userId));
            if (cartDetails == null)
            {
                return NotFound(new { statusCode = 404, message = "No cart details found" });
            }
            return Ok(cartDetails);
        }

        [HttpGet("getCartItemCount/{userId}")]
        public async Task<IActionResult> GetCartQuantity(int userId)
        {
            var cart = await _mediator.Send(new GetCartItemCount { UserId = userId });
            return Ok(cart);
        }

        [HttpPost("decrementFromCart")]
        public async Task<IActionResult> DecrementFromCart(DecrementFromCartDto decrementFromCartDto)
        {
            var cartQuanity = await _mediator.Send(new DecrementFromCartCommand { DecrementFromCartDto = decrementFromCartDto });
            return Ok(cartQuanity);
        }

        [HttpPost("validateCard")]
        public async Task<IActionResult> ValidateCard(CartPaymentDto card)
        {
            var result = await _mediator.Send(new InvoiceCommand { CartPaymentDto = card });
            
            return Ok(result);
        }

        [HttpGet("generateInvoice/{userId}")]
        public async Task<IActionResult> GenerateInvoice(int userId)
        {
            var payment = await _mediator.Send(new GetInvoiceDetailQuery { SalesId = userId });
            return Ok(payment);
        }


    }
}
