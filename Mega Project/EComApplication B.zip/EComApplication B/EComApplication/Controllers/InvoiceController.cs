﻿using Core.App.Invoice;
using Core.Models.Cart;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EComApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IMediator _mediator;

        public InvoiceController(IMediator mediator)
        {
            _mediator = mediator;
        }

        //[HttpPost("generateInvoice")]
        //public async Task<IActionResult> GenerateInvoice(InvoiceDto model)
        //{
        //    var result = await _mediator.Send(new InvoiceCommand { InvoiceDto = model });
        //    return Ok(result);
        //}
    }
}
