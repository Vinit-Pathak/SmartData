﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Sales
{
    public class SalesDetail
    {
        [Key]
        public int SalesId { get; set; }
        [Required]
        [ForeignKey("SalesMaster")]
        public int InvoiceId { get; set; }
        public SalesMaster SalesMaster { get; set; }

        [ForeignKey("Product")]
        public int PrId { get; set; }
        public Product Product { get; set; }
        [Required]
        public string ProductCode { get; set; }
        [Required]
        public int SalesQty { get; set; }
        [Required]
        public float SellingPrice { get; set; }
    }
}
