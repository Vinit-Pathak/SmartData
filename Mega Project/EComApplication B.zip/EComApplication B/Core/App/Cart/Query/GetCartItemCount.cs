﻿using Core.Interface;
using Dapper;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Cart.Query
{
    public class GetCartItemCount: IRequest<object>
    {
        public int UserId { get; set; }
    }

    public class GetCartItemCountHandler : IRequestHandler<GetCartItemCount, object>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetCartItemCountHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<object> Handle(GetCartItemCount request, CancellationToken cancellationToken)
        {

            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            var connection = new SqlConnection(connectionString);
            const string query = @"select cd.ProductId from CartMaster cm
                                    inner join CartDetails cd on cm.CartId = cd.CartId
                                    where cm.UserId = @UserId";

            var parameters = new { UserId = request.UserId };
            var count = await connection.QueryAsync<int>(query, parameters);

            var response = new
            {
                statusCode = 200,
                message = "Success",
                cartProductId = count
            };

            return response;

        }
    }
}
