﻿using Core.Interface;
using Core.Models.Cart;
using Dapper;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Cart.Query
{
    public class GetCartDetailsQuery: IRequest<object>
    {
        public int UserId { get; set; }
        public GetCartDetailsQuery(int userId)  
        {
            UserId = userId;
        }
    }

    public class GetCartDetailsQueryHandler : IRequestHandler<GetCartDetailsQuery, object>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetCartDetailsQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<object> Handle(GetCartDetailsQuery request, CancellationToken cancellationToken)
        {
            using (var connection = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            {
                var query = @"
                              SELECT 
                                c.Id,
                                c.CartId,
                                c.ProductId,
                                c.Quantity,
                                p.ProductName,
                                p.SellingPrice As Price,
                                p.Category,
                                p.Brand,
                                p.ProductCode,
                                p.ProductImage
                                FROM CartMaster cm
                                INNER JOIN CartDetails c ON cm.CartId = c.CartId
                                INNER JOIN Products p ON c.ProductId = p.Id
                                WHERE cm.UserId = @UserId
                                AND p.IsDeleted = 0
                                ";

                var parameters = new { UserId = request.UserId };
                var cartDetails = await connection.QueryAsync<CartDetailDto>(query, parameters);

                var response = cartDetails.ToList();
                return new
                {

                    statusCode = 200,
                    data = response

                };

                

            }


        }
    }
}
