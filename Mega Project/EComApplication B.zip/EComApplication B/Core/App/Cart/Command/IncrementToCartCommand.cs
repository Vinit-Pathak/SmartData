﻿using Core.Interface;
using Core.Models.Cart;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Cart.Command
{
    public class IncrementToCartCommand: IRequest<object>
    {
        public IncrementToCartDto IncrementToCart { get; set; }
    }

    public class IncrementToCartCommandHandler : IRequestHandler<IncrementToCartCommand, object>
    {
        private readonly IAppDbContext _context;

        public IncrementToCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<object> Handle(IncrementToCartCommand request, CancellationToken cancellationToken)
        {
            var cartRequest = request.IncrementToCart;

            // Fetch the correct cart item by cartId and productId
            var cartDetail = await _context.Set<Domain.Cart.CartDetails>()
                .FirstOrDefaultAsync(x => x.CartId == cartRequest.CartId && x.ProductId == cartRequest.ProductId, cancellationToken);

            if (cartDetail == null)
            {
                return new { statusCode = 404, message = "Item not found in the cart", data = cartRequest };
            }

            var product = await _context.Set<Domain.Product>()
                .FirstOrDefaultAsync(p => p.Id == cartRequest.ProductId, cancellationToken);

            if (product == null)
            {
                return new { statusCode = 404, message = "Product not found", data = cartRequest };
            }

            if (cartDetail.Quantity + cartRequest.Quantity > product.Stock)
            {
                return new { statusCode = 400, message = "Product not in stock" };
            }

            cartDetail.Quantity += cartRequest.Quantity;
            await _context.SaveChangesAsync(cancellationToken);

            return new
            {
                statusCode = 200,
                message = "Item added to cart successfully.",
                cartQuantity = cartDetail.Quantity,
                stockAvailable = product.Stock

            };
        }

    }
}
