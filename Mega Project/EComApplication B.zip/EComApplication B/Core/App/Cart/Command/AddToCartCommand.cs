﻿using Core.Interface;
using Core.Models.Cart;
using Domain.Cart;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Cart.Command
{
    public class AddToCartCommand: IRequest<object>
    {
        public AddToCartDto AddToCart { get; set; }
    }

    public class AddToCartCommandHandler : IRequestHandler<AddToCartCommand, object>
    {
        private readonly IAppDbContext _context;

        public AddToCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<object> Handle(AddToCartCommand request, CancellationToken cancellationToken)
        {
            var cart = request.AddToCart;
            var userExists = await _context.Set<CartMaster>()
                .FirstOrDefaultAsync(x => x.UserId == cart.UserId);

            if (userExists == null) {
                var cartMaster = new CartMaster
                {
                    UserId = cart.UserId,
                };
                await _context.Set<CartMaster>().AddAsync(cartMaster);
                await _context.SaveChangesAsync(cancellationToken);
                userExists = cartMaster;

            }

            var product = await _context.Set<Domain.Product>()
                            .FirstOrDefaultAsync(x => x.Id == cart.UserId);
            if (product == null) {
                return "Product not found";
            }

            var cartDetail = new Domain.Cart.CartDetails
            {
                CartId = userExists.CartId,
                ProductId = cart.ProductId,
                Quantity = cart.Quantity,
            };

            await _context.Set<Domain.Cart.CartDetails>().AddAsync(cartDetail);
            await _context.SaveChangesAsync(cancellationToken);

            return new
            {
                CartMaster = userExists,
                Product = product,
                Quantity = cart.Quantity
            };
        }
    }
}
