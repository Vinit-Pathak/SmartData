﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Core.Interface;
using Core.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Command
{
    public class UpdateUserByIdCommand: IRequest<object>
    {
        public RegisterDto User{ get; set; }
        public int Id { get; set; }
        public Stream FileStream { get; set; }
        public string FileName { get; set; }

    }

    public class UpdateUserByIdCommandHandler : IRequestHandler<UpdateUserByIdCommand, object>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images";

        public UpdateUserByIdCommandHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");

        }
        public async Task<object> Handle(UpdateUserByIdCommand request, CancellationToken cancellationToken)
        {
            var id = request.Id;
            var user = await _context.Set<Domain.User>().FirstOrDefaultAsync(x => x.Id == id && x.IsActive == true);
            if (user == null)
            {
                return "User not found";
            }

            var imageUrl = string.Empty;

            if (request.FileName != null)
            {
                // STORING IMAGES
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName) // Get MIME type dynamically
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                imageUrl = blobClient.Uri.ToString();
            }

            user.FirstName = request.User.FirstName;
            user.LastName = request.User.LastName;
            user.Email = request.User.Email;
            user.Mobile = request.User.Mobile;
            user.DateOfBirth = request.User.DateOfBirth;
            if (!string.IsNullOrEmpty(imageUrl))
            {
                user.ProfileImage = imageUrl;
            }
            user.UserType = request.User.UserType;
            user.Address = request.User.Address;
            user.ZipCode = request.User.ZipCode;
            user.State = request.User.State;
            user.Country = request.User.Country;
            user.IsActive = true;

            await _context.SaveChangesAsync(cancellationToken);
            return user;
        }

        private string GetContentType(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream",
            };
        }
    }
}
