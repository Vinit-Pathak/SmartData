﻿using Core.Interface;
using Core.Models.Cart;
using Dapper;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Invoice
{
    public class GetInvoiceDetailQuery:IRequest<object>
    {
        public int SalesId { get; set; }
    }

    public class GetInvoiceDetailQueryHandler : IRequestHandler<GetInvoiceDetailQuery, object>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetInvoiceDetailQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<object> Handle(GetInvoiceDetailQuery request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);

            const string query = @"
                            SELECT 
                            u.Id,
                            u.FirstName,
                            u.LastName,
                            u.Email,
                            u.Mobile,
                            u.Address,
                            u.ZipCode,
                            sm.InvoiceId,
                            sm.OrderDate,
                            sm.TotalAmount,
                            sm.DeliveryAddress,
                            sm.DeliveryZipCode,
                            sm.DeliveryState,
                            sm.DeliveryCountry,
                            c.Name AS DeliveryCountryName,
                            st.Name AS DeliveryStateName,
                            p.ProductName,
                            sd.ProductCode,
                            sd.SalesQty,    
                            sd.SellingPrice
                        FROM SalesMasters sm
                        INNER JOIN [Users] u ON sm.UserId = u.Id
                        INNER JOIN SalesDetails sd ON sm.SalesId = sd.InvoiceId
                        INNER JOIN Products p ON sd.PrId = p.Id
                        LEFT JOIN Country c ON sm.DeliveryCountry = c.CountryId 
                        LEFT JOIN State st ON sm.DeliveryState = st.StateId 
                        WHERE sm.SalesId = @SalesId";

            var parameter = new {SalesId = request.SalesId};

            var invoiceDetails = await connection.QueryAsync<InvoideDetailsDto>(query, parameter);

            var groupInvoice = invoiceDetails
                .GroupBy(x => new
                {
                    x.InvoiceId,
                    x.Id,
                    x.FirstName,
                    x.LastName,
                    x.Email,
                    x.Mobile,
                    x.Address,
                    x.DeliveryZipCode,
                    x.DeliveryStateName,
                    x.DeliveryCountryName,
                    x.OrderDate,
                    x.TotalAmount
                })
                .Select(g => new
                {
                    InvoiceId = g.Key.InvoiceId,
                    UserId = g.Key.Id,
                    FirstName = g.Key.FirstName,
                    LastName = g.Key.LastName,
                    Email = g.Key.Email,
                    Mobile = g.Key.Mobile,
                    Address = g.Key.Address,
                    ZipCode = g.Key.DeliveryZipCode,
                    State = g.Key.DeliveryStateName,
                    Country = g.Key.DeliveryCountryName,
                    OrderDate = g.Key.OrderDate,
                    TotalAmount = g.Key.TotalAmount,
                    Products = g.Select(p => new
                    {
                        ProductName = p.ProductName,
                        ProductCode = p.ProductCode,
                        SalesQty = p.SalesQty,
                        SellingPrice = p.SellingPrice
                    }).ToList()
                }).FirstOrDefault();

            var response = new
            {
                statusCode = groupInvoice != null ? 200 : 404,
                message = groupInvoice != null ? "Invoice Details Retrieved Successfully" : "Invoice not found",
                invoice = groupInvoice
            };
            return response;
        }
    }
}
