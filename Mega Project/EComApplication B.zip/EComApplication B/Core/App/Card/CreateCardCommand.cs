﻿using Core.Interface;
using Core.Models;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Card
{
    public class CreateCardCommand: IRequest<bool>
    {
        public CardDto Card { get; set; }
    }

    public class CreateCardCommandHandler : IRequestHandler<CreateCardCommand, bool>
    {
        private readonly IAppDbContext _context;

        public CreateCardCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Handle(CreateCardCommand request, CancellationToken cancellationToken)
        {
            var card = new Domain.Card
            {
                CardNumber = request.Card.CardNumber,
                ExpiryDate = request.Card.ExpiryDate,
                CVV = request.Card.CVV
            };
            _context.Set<Domain.Card>().Add(card);
            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }
    }

}
