﻿using Core.Interface;
using Core.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Card
{
    public class ValidateCardQuery: IRequest<bool>
    {
        public CardDto Card { get; set; }
    }

    public class ValidateCardQueryHandler : IRequestHandler<ValidateCardQuery, bool>
    {
        private readonly IAppDbContext _context;

        public ValidateCardQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Handle(ValidateCardQuery request, CancellationToken cancellationToken)
        {
            var cardRequest = request.Card;
            var card = await _context.Set<Domain.Card>()
                .FirstOrDefaultAsync(c => c.CardNumber == cardRequest.CardNumber && c.ExpiryDate == cardRequest.ExpiryDate && c.CVV == cardRequest.CVV, cancellationToken);

            await _context.SaveChangesAsync(cancellationToken);
            return card != null;
        }
    }

}
