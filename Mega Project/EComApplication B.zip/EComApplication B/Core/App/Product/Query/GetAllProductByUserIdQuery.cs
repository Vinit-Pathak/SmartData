﻿using Core.Interface;
using Dapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Product.Query
{
    public class GetAllProductByUserIdQuery: IRequest<List<Domain.Product>>
    {
        public int UserId { get; set; }
    }

    public class GetAllProductByUserIdQueryHandler : IRequestHandler<GetAllProductByUserIdQuery, List<Domain.Product>>
    {
        private readonly IAppDbContext _context;

        public GetAllProductByUserIdQueryHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Domain.Product>> Handle(GetAllProductByUserIdQuery request, CancellationToken cancellationToken)
        {
            using var connection = _context.GetConnection();
            var query = "SELECT * FROM Products WHERE UserId = @UserId AND IsDeleted = 0";
            var products = await connection.QueryAsync<Domain.Product>(query, new { UserId = request.UserId });

            return products.ToList();
        }
    }
}
