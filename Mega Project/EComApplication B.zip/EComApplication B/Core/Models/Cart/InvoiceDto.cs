﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Cart
{
    public class InvoiceDto
    {
        public int UserId{ get; set; }
        public string Address { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int ZipCode { get; set; }
    }
}
