﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    public class CardDto
    {
        public int CardNumber { get; set; }
        public string ExpiryDate { get; set; }
        public int CVV { get; set; }
    }
}
