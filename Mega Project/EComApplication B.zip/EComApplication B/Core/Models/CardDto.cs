﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models
{
    public class CardDto
    {
       
        public string CardNumber { get; set; }
        
        public string ExpiryDate { get; set; } = DateTime.Now.ToString("MM/yy");
        
        public string CVV { get; set; }
    }
}
