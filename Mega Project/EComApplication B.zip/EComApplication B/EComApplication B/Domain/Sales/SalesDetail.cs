﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Sales
{
    public class SalesDetail
    {
        [Key]
        public int SalesDetailsId { get; set; }

        [ForeignKey("Product")]
        public int PrId { get; set; }
        public Product Product { get; set; }
        public string InvoiceId { get; set; }

        public string ProductCode { get; set; }

        public int SalesQty { get; set; }

        public float SellingPrice { get; set; }
    }
}
