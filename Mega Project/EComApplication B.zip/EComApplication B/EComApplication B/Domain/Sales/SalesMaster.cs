﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Sales
{
    public class SalesMaster
    {
        [Key]
        public int SalesId { get; set; }
        public string InvoiceId { get; set; }
        public int UserId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public float Price { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }
        public string DeliveryAddress { get; set; }
        public int DeliveryZipCode { get; set; }
        public int DeliveryState { get; set; }
        public int DeliveryCountry { get; set; }
    }
}
