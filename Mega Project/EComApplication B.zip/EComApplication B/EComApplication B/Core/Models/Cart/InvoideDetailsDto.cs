﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Cart
{
    public class InvoideDetailsDto
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public int DeliveryState { get; set; }
        public int DeliveryCountry {  get; set; }
        public string DeliveryCountryName { get; set; } // The country name
        public string DeliveryStateName { get; set; }
        public int DeliveryZipCode { get; set; }
        public string InvoiceId { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }
        public string ProductName { get; set; }
        public string ProductCode { get; set; }
        public int SalesQty { get; set; }
        public float SellingPrice { get; set; }

    }
}
