﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Cart
{
    public class CartPaymentDto
    {
        public int UserId { get; set; }
        public string CardNumber { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Cvv { get; set; }
        public string Address { get; set; }
        public int State { get; set; }
        public int Country { get; set; }
        public int ZipCode { get; set; }
    }
}
