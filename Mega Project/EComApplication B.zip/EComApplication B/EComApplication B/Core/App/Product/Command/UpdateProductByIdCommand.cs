﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Core.Interface;
using Core.Models;
using Domain;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Product.Command
{
    public class UpdateProductByIdCommand: IRequest<bool>
    {
        public ProductDto Product { get; set; }
        public int Id { get; set; }
        public Stream FileStream { get; set; }
        public string FileName { get; set; }
    }

    public class UpdateProductByIdCommandHandler : IRequestHandler<UpdateProductByIdCommand, bool>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images";

        public UpdateProductByIdCommandHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");
        }
        public async Task<bool> Handle(UpdateProductByIdCommand request, CancellationToken cancellationToken)
        {
            var id = request.Id;
            var product = await _context.Set<Domain.Product>().FirstOrDefaultAsync(x => x.Id == id && x.IsDeleted == false);
            if (product == null)
            {
                return false;
            }

            product.ProductName = request.Product.ProductName;
            product.Category = request.Product.Category;
            product.Brand = request.Product.Brand;
            product.SellingPrice = request.Product.SellingPrice;
            product.PurchasePrice = request.Product.PurchasePrice;
            product.PurchaseDate = request.Product.PurchaseDate;
            product.Stock = request.Product.Stock;
            product.UpdatedAt = DateTime.Now;
            product.IsDeleted = false;

            if (request.FileStream != null && !string.IsNullOrEmpty(request.FileName))
            {
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName)
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                product.ProductImage = blobClient.Uri.ToString();
            }

            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }

        private string GetContentType(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream",
            };
        }
    }
}
