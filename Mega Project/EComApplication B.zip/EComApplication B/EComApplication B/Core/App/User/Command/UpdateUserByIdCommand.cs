﻿using Azure.Storage.Blobs.Models;
using Azure.Storage.Blobs;
using Core.Interface;
using Core.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.Command
{
    public class UpdateUserByIdCommand: IRequest<bool>
    {
        public RegisterDto User{ get; set; }
        public int Id { get; set; }
        public Stream FileStream { get; set; }
        public string FileName { get; set; }

    }

    public class UpdateUserByIdCommandHandler : IRequestHandler<UpdateUserByIdCommand, bool>
    {
        private readonly IAppDbContext _context;
        private readonly string _connectionString;
        private readonly string _containerName = "ecomapplication";
        private readonly string _folderName = "profile-images";

        public UpdateUserByIdCommandHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("AzureBlobStorage");

        }
        public async Task<bool> Handle(UpdateUserByIdCommand request, CancellationToken cancellationToken)
        {
            var id = request.Id;
            var user = await _context.Set<Domain.User>().FirstOrDefaultAsync(x => x.Id == id && x.IsActive == true);
            if (user == null)
            {
                return false;
            }

            user.FirstName = request.User.FirstName;
            user.LastName = request.User.LastName;
            user.Email = request.User.Email;
            user.Mobile = request.User.Mobile;
            user.DateOfBirth = request.User.DateOfBirth;
            user.UserType = request.User.UserType;
            user.Address = request.User.Address;
            user.ZipCode = request.User.ZipCode;
            user.State = request.User.State;
            user.Country = request.User.Country;
            user.IsActive = true;

            if (request.FileStream != null && !string.IsNullOrEmpty(request.FileName))
            {
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                var blobClient = blobContainerClient.GetBlobClient($"{_folderName}/{Guid.NewGuid()}");

                var blobHttpHeaders = new BlobHttpHeaders
                {
                    ContentType = GetContentType(request.FileName)
                };

                await blobClient.UploadAsync(request.FileStream, new BlobUploadOptions
                {
                    HttpHeaders = blobHttpHeaders
                });

                user.ProfileImage = blobClient.Uri.ToString();
            }

            await _context.SaveChangesAsync(cancellationToken);
            return true;
        }

        private string GetContentType(string fileName)
        {
            var extension = Path.GetExtension(fileName).ToLowerInvariant();
            return extension switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".gif" => "image/gif",
                _ => "application/octet-stream",
            };
        }
    }
}
