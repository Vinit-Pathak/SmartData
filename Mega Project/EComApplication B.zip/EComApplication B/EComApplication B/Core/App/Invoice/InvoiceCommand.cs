﻿using Core.Interface;
using Core.Models.Cart;
using Domain;
using Domain.Sales;
using Mapster;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PasswordGenerator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Invoice
{
    public class InvoiceCommand: IRequest<object>
    {
        public CartPaymentDto CartPaymentDto{ get; set; }

    }
    public class InvoiceCommandHandler : IRequestHandler<InvoiceCommand, object>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
      

        public InvoiceCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<object> Handle(InvoiceCommand request, CancellationToken cancellationToken)
        {
            var paymentDto = request.CartPaymentDto;
            var card = await _context.Set<Domain.Card>()
                        .FirstOrDefaultAsync(c=>c.CardNumber == paymentDto.CardNumber && c.CVV == paymentDto.Cvv, cancellationToken);
            if (card is null)
            {
                return new
                {
                    statusCode = 401,
                    message = "Invalid Credentials",
                    data = card
                };
            }

            if(card.ExpiryDate.ToString("MM/dd/yyyy") != paymentDto.ExpiryDate.ToString("MM/dd/yyyy"))
            {
                return "Wrong Expiry Date";
            }

            var cardDetailList = await (from cartMaster in _context.Set<Domain.Cart.CartMaster>()
                                        join cartDetail in _context.Set<Domain.Cart.CartDetails>()
                                        on cartMaster.CartId equals cartDetail.CartId
                                        where (cartMaster.UserId == paymentDto.UserId)
                                        select new Domain.Cart.CartDetails
                                        {
                                            Id = cartDetail.Id,
                                            CartId = cartDetail.CartId,
                                            CartMaster = cartDetail.CartMaster,
                                            Product = cartDetail.Product,
                                            Quantity = cartDetail.Quantity,
                                            ProductId = cartDetail.ProductId,
                                        }).ToListAsync(cancellationToken);
           
            if(!cardDetailList.Any())
            {
                return $"No items in cart";
            }

            float subTotal = 0;
            foreach (var item in cardDetailList)
            {
                var product = await _context.Set<Domain.Product>()
                                .FirstOrDefaultAsync(p =>p.Id == item.ProductId, cancellationToken);

                if (product is null || !(product.Stock >= item.Quantity))
                {
                    return new
                    {
                        statusCode = 404,
                        message = "Item out of stock",
                        data = product
                    };
                }

                subTotal += product.SellingPrice * (item.Quantity);
            }
            int totalSalesMaster = await _context.Set<Domain.Sales.SalesMaster>()
                                        .CountAsync(cancellationToken);
            totalSalesMaster++;

            SalesMaster salesMaster = new SalesMaster()
            {
                OrderDate = DateTime.Now,
                TotalAmount =subTotal,
                DeliveryAddress = paymentDto.Address,
                DeliveryCountry = paymentDto.Country,
                DeliveryState = paymentDto.State,
                DeliveryZipCode = paymentDto.ZipCode,
                UserId = paymentDto.UserId,
                InvoiceId = "ORD"+totalSalesMaster.ToString().PadLeft(3, '0'),

            };

            await _context.Set<Domain.Sales.SalesMaster>()
                        .AddAsync(salesMaster, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            salesMaster.InvoiceId = "ORDER" + salesMaster.SalesId.ToString().PadLeft(3, '0');
            await _context.SaveChangesAsync(cancellationToken);

            foreach(var item in cardDetailList)
            {
                var product = await _context.Set<Domain.Product>()
                                .FirstOrDefaultAsync(p => p.Id == item.ProductId, cancellationToken);

                SalesDetail salesDetail = new SalesDetail()
                {
                    InvoiceId = salesMaster.SalesId,
                    ProductCode = product.ProductCode,
                    PrId = product.Id,
                    SalesQty = item.Quantity,
                    SalesMaster = salesMaster,
                    SellingPrice = product.SellingPrice
                };

                await _context.Set<Domain.Sales.SalesDetail>()
                            .AddAsync(salesDetail, cancellationToken);
                product.Stock = product.Stock - item.Quantity;

                _context.Set<Domain.Cart.CartDetails>().Remove(item);

                await _context.SaveChangesAsync(cancellationToken);
            }

            var response = new
            {
                statusCode = 200,
                message = "Order Placed Successfully",
                data = salesMaster
            };

            return response;
            
        }



    }

    
}
