﻿using Core.Interface;
using Core.Models.Cart;
using Domain;
using Domain.Sales;
using Mapster;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Invoice
{
    public class InvoiceCommand: IRequest<object>
    {
        public InvoiceDto InvoiceDto { get; set; }

    }
    public class InvoiceCommandHandler : IRequestHandler<InvoiceCommand, object>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
      

        public InvoiceCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<object> Handle(InvoiceCommand request, CancellationToken cancellationToken)
        {
            object obj = "";
            var salesMaster = new SalesMaster
            {
                InvoiceId = $"ORD-{DateTime.Now:yyMMdd}-{Guid.NewGuid().ToString().Substring(0, 3)}", // Auto-generate Invoice ID
                UserId = request.InvoiceDto.UserId,
                OrderDate = DateTime.Now,
                TotalAmount = (float)request.InvoiceDto.Items.Sum(i => i.Price * i.Quantity),
                DeliveryAddress = request.InvoiceDto.Address,
                DeliveryZipCode = request.InvoiceDto.ZipCode,
                DeliveryState = request.InvoiceDto.State,
                DeliveryCountry = request.InvoiceDto.Country
            };
            await _context.Set<SalesMaster>().AddAsync(salesMaster);
            await _context.SaveChangesAsync();

            foreach (var item in request.InvoiceDto.Items)
            {
                var salesDetail = new SalesDetail
                {
                    InvoiceId = salesMaster.InvoiceId,
                    PrId = item.ProductId,
                    ProductCode = item.ProductCode,
                    SalesQty = item.Quantity,
                    SellingPrice = item.Price,
                };
                var product = await _context.Set<Domain.Product>().FindAsync(item.ProductId);
                if (product == null || product.Stock < item.Quantity)
                {
                    return new
                    {
                        statusCode = 404,
                        message = "Product not found or out of stock"
                    };
                }
                product.Stock -= item.Quantity;
                await _context.Set<SalesDetail>().AddAsync(salesDetail);
                obj = salesDetail;

            }
            await _context.SaveChangesAsync();

            var checkUser = await _context.Set<Domain.User>().FirstOrDefaultAsync(x => x.Id == request.InvoiceDto.UserId);

            await _emailService.SendEmailAsync(checkUser.Email, "Order Confirmation", $"Your invoice has been sent to your registered email successfully and Your Invoice is {salesMaster.Adapt<InvoiceDto>()}");

            return new
            {
                statusCode = 200,
                message = "Invoice created successfully",
                data = salesMaster
            };
        }



    }

    }
}
