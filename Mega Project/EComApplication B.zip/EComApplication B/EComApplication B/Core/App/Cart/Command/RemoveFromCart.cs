﻿using Core.Interface;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;
using System.Threading.Tasks;

namespace Core.App.Cart.Command
{
    public class RemoveFromCartCommand : IRequest<object>
    {
        public int CartId { get; set; }
    }

    public class RemoveFromCartCommandHandler : IRequestHandler<RemoveFromCartCommand, object>
    {
        private readonly IAppDbContext _context;

        public RemoveFromCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }

        public async Task<object> Handle(RemoveFromCartCommand request, CancellationToken cancellationToken)
        {
            var cartId = request.CartId;

            var cartDetail = await _context.Set<Domain.Cart.CartDetails>()
                .FirstOrDefaultAsync(x => x.CartId == cartId, cancellationToken);

            if (cartDetail == null)
            {
                return new
                {
                    statusCode = 404,
                    message = "Item not found in the cart."
                };
            }

            _context.Set<Domain.Cart.CartDetails>().Remove(cartDetail);
            await _context.SaveChangesAsync(cancellationToken);

            return new
            {
                statusCode = 200,
                message = "Item removed successfully.",
                data = cartId
            };
        }
    }
}