﻿using Core.Interface;
using Core.Models.Cart;
using Domain.Cart;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Cart.Command
{
    public class DecrementFromCartCommand: IRequest<object>
    {
        public DecrementFromCartDto DecrementFromCartDto { get; set; }
    }

    public class DecrementFromCartCommandHandler : IRequestHandler<DecrementFromCartCommand, object>
    {
        private readonly IAppDbContext _context;

        public DecrementFromCartCommandHandler(IAppDbContext context)
        {
            _context = context;
        }
        public async Task<object> Handle(DecrementFromCartCommand request, CancellationToken cancellationToken)
        {
            var decrementQuantity = request.DecrementFromCartDto;
            var checkProduct = await _context.Set<CartDetails>()
                .FirstOrDefaultAsync(x => x.CartId == decrementQuantity.CartId && x.ProductId == decrementQuantity.ProductId, cancellationToken);

            if (checkProduct is null)
            {
                return new
                {
                    statusCode = 404,
                    message = "Item not found in cart",
                    data = decrementQuantity
                };
            }

            // Ensure we do not decrement below 0
            if (checkProduct.Quantity <= 0)
            {
                return new
                {
                    statusCode = 400,
                    message = "Cannot decrement, item quantity is already zero",
                    data = decrementQuantity
                };
            }

            // Decrease quantity by 1, ensuring no negative quantities
            checkProduct.Quantity -= decrementQuantity.Quantity;
            if (checkProduct.Quantity < 0)
            {
                checkProduct.Quantity = 0;  // Ensure quantity is not negative
            }

            await _context.SaveChangesAsync(cancellationToken);

            var response = new
            {
                statusCode = 200,
                message = "Item decremented from cart",
                cartQuantity = checkProduct.Quantity
            };

            return response;
        }


    }
}
