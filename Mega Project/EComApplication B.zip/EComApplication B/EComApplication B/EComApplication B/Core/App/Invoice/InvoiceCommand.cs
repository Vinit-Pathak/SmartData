﻿using Core.Interface;
using Core.Models.Cart;
using Domain;
using Domain.Cart;
using Domain.Sales;
using Mapster;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PasswordGenerator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.Invoice
{
    public class InvoiceCommand: IRequest<object>
    {
        public CartPaymentDto CartPaymentDto{ get; set; }

    }
    public class InvoiceCommandHandler : IRequestHandler<InvoiceCommand, object>
    {
        private readonly IAppDbContext _context;
        private readonly IEmailService _emailService;
      

        public InvoiceCommandHandler(IAppDbContext context, IEmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }
        public async Task<object> Handle(InvoiceCommand request, CancellationToken cancellationToken)
        {
            var paymentDto = request.CartPaymentDto;
            var card = await _context.Set<Domain.Card>()
                        .FirstOrDefaultAsync(c=>c.CardNumber == paymentDto.CardNumber && c.CVV == paymentDto.Cvv, cancellationToken);
            if (card is null)
            {
                return new
                {
                    statusCode = 401,
                    message = "Invalid Credentials",
                    data = card
                };
            }

            if(card.ExpiryDate.ToString("MM/dd/yyyy") != paymentDto.ExpiryDate.ToString("MM/dd/yyyy"))
            {
                return "Wrong Expiry Date";
            }

            var cardDetailList = await (from cartMaster in _context.Set<Domain.Cart.CartMaster>()
                                        join cartDetail in _context.Set<Domain.Cart.CartDetails>()
                                        on cartMaster.CartId equals cartDetail.CartId
                                        where (cartMaster.UserId == paymentDto.UserId)
                                        select new Domain.Cart.CartDetails
                                        {
                                            Id = cartDetail.Id,
                                            CartId = cartDetail.CartId,
                                            CartMaster = cartDetail.CartMaster,
                                            Product = cartDetail.Product,
                                            Quantity = cartDetail.Quantity,
                                            ProductId = cartDetail.ProductId,
                                        }).ToListAsync(cancellationToken);
           
            if(!cardDetailList.Any())
            {
                return $"No items in cart";
            }

            float subTotal = 0;
            foreach (var item in cardDetailList)
            {
                var product = await _context.Set<Domain.Product>()
                                .FirstOrDefaultAsync(p =>p.Id == item.ProductId, cancellationToken);

                if (product is null || !(product.Stock >= item.Quantity))
                {
                    return new
                    {
                        statusCode = 404,
                        message = "Item out of stock",
                        data = product
                    };
                }

                subTotal += product.SellingPrice * (item.Quantity);
            }
            int totalSalesMaster = await _context.Set<Domain.Sales.SalesMaster>()
                                        .CountAsync(cancellationToken);
            totalSalesMaster++;

            SalesMaster salesMaster = new SalesMaster()
            {
                OrderDate = DateTime.Now,
                TotalAmount =subTotal,
                DeliveryAddress = paymentDto.Address,
                DeliveryCountry = paymentDto.Country,
                DeliveryState = paymentDto.State,
                DeliveryZipCode = paymentDto.ZipCode,
                UserId = paymentDto.UserId,
                InvoiceId = "ORD"+totalSalesMaster.ToString().PadLeft(3, '0'),

            };

            await _context.Set<Domain.Sales.SalesMaster>()
                        .AddAsync(salesMaster, cancellationToken);
            await _context.SaveChangesAsync(cancellationToken);

            salesMaster.InvoiceId = "ORDER" + salesMaster.SalesId.ToString().PadLeft(3, '0');
            await _context.SaveChangesAsync(cancellationToken);

            foreach(var item in cardDetailList)
            {
                var product = await _context.Set<Domain.Product>()
                                .FirstOrDefaultAsync(p => p.Id == item.ProductId, cancellationToken);

                SalesDetail salesDetail = new SalesDetail()
                {
                    InvoiceId = salesMaster.SalesId,
                    ProductCode = product.ProductCode,
                    PrId = product.Id,
                    SalesQty = item.Quantity,
                    SalesMaster = salesMaster,
                    SellingPrice = product.SellingPrice
                };

                await _context.Set<Domain.Sales.SalesDetail>()
                            .AddAsync(salesDetail, cancellationToken);
                product.Stock = product.Stock - item.Quantity;

                _context.Set<Domain.Cart.CartDetails>().Remove(item);

                await _context.SaveChangesAsync(cancellationToken);
            }

            var user = await _context.Set<Domain.User>()
                                  .FirstOrDefaultAsync(u => u.Id == paymentDto.UserId, cancellationToken);

            if (user == null)
            {
                return new
                {
                    statusCode = 404,
                    message = "User not found"
                };
            }

            var country = await _context.Set<Domain.Country>()
                                    .FirstOrDefaultAsync(c => c.CountryId == paymentDto.Country, cancellationToken);

            var state = await _context.Set<Domain.State>()
                                       .FirstOrDefaultAsync(s => s.StateId == paymentDto.State, cancellationToken);

            // Generate Invoice HTML with Country and State names
            var emailContent = GenerateInvoiceHtml(salesMaster, cardDetailList, country?.Name, state?.Name);


            var userEmail = user.Email; // Get the user's email address

            var emailSubject = "Order Placed Successfully";

            // Send the invoice email
            var emailResponse = await _emailService.SendEmailAsync(userEmail, emailSubject, emailContent);
            if (emailResponse is not bool emailSent || !emailSent)
            {
                return new
                {
                    statusCode = 500,
                    message = "Failed to send invoice email"
                };
            }

            var response = new
            {
                statusCode = 200,
                message = "Order Placed Successfully. Invoice has been sent to your email.",
                data = salesMaster
            };

            return response;

        }


        private string GenerateInvoiceHtml(SalesMaster salesMaster, List<CartDetails> cartDetails, string countryName, string stateName)
    {
        var sb = new StringBuilder();

        sb.Append("<html><body>");
        sb.Append("<h1>Invoice</h1>");
        sb.Append($"<p><strong>Invoice ID:</strong> {salesMaster.InvoiceId}</p>");
        sb.Append($"<p><strong>Order Date:</strong> {salesMaster.OrderDate}</p>");
        sb.Append($"<p><strong>Delivery Address:</strong> {salesMaster.DeliveryAddress}, {stateName}, {countryName}, {salesMaster.DeliveryZipCode}</p>");
        sb.Append("<h2>Items</h2>");
        sb.Append("<table border='1'><tr><th>Product</th><th>Quantity</th><th>Price</th><th>Total</th></tr>");
        
        float totalAmount = 0;
        foreach (var item in cartDetails)
        {
            var product = item.Product;
            float itemTotal = product.SellingPrice * item.Quantity;
            totalAmount += itemTotal;
            
            sb.Append($"<tr><td>{product.ProductCode} - {product.ProductName}</td><td>{item.Quantity}</td><td>${product.SellingPrice}</td><td>${itemTotal}</td></tr>");
        }

        sb.Append("</table>");
        sb.Append($"<h3>Total: ${totalAmount}</h3>");
        sb.Append("</body></html>");

        return sb.ToString();
        }


    }

    
}
