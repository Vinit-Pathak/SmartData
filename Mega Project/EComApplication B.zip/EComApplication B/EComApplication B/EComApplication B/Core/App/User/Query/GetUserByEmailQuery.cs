﻿using Core.Interface;
using Core.Models;
using Dapper;
using MediatR;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.App.User.NewFolder
{
    public class GetUserByEmailQuery: IRequest<object>
    {
        public string Email { get; set; }
    }

    public class GetUserByEmailQueryHandler : IRequestHandler<GetUserByEmailQuery, object>
    {
        private readonly IAppDbContext _context;
        private readonly IConfiguration _configuration;

        public GetUserByEmailQueryHandler(IAppDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public async Task<object> Handle(GetUserByEmailQuery request, CancellationToken cancellationToken)
        {
            var connectionString = _configuration.GetConnectionString("DefaultConnection");
            using var connection = new SqlConnection(connectionString);

            const string query = @"
                            SELECT 
                                u.Id,
                                u.FirstName,
                                u.LastName,
                                u.Email,
                                u.UserName,
                                u.Password,
                                u.Mobile,
                                u.DateOfBirth,
                                u.UserType,
                                u.ProfileImage,
                                u.Address,
                                u.ZipCode,
                                c.Name AS CountryName,  
                                st.Name AS StateName,  
                                u.IsActive
                                FROM Users u
                                LEFT JOIN Country c ON u.Country = c.CountryId 
                                LEFT JOIN State st ON u.State = st.StateId      
                                WHERE u.Email = @Email AND u.IsActive = 1";

            var parameter = new { Email = request.Email };
            var userData = await connection.QueryAsync<UserDto>(query, parameter);

            var response = new
            {
                statusCode = userData != null ? 200 : 404,
                message = userData != null ? "Userdata found successfully" : "No user data found",
                data = userData
            };

            return response;
        }
    }
}
