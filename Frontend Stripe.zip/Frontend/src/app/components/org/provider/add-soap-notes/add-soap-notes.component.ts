import { Component } from '@angular/core';

@Component({
  selector: 'app-add-soap-notes',
  standalone: true,
  imports: [],
  templateUrl: './add-soap-notes.component.html',
  styleUrl: './add-soap-notes.component.css'
})
export class AddSoapNotesComponent {

}
