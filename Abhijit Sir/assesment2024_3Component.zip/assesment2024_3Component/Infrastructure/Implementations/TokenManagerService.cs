﻿using Core.Common.Interfaces;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using Core.Features.Account.Response;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Infrastructure.Implementation
{
    public class TokenManagerService : ITokenManager
    {
        private readonly IJwtIssuerOptions _options;

        public TokenManagerService(IJwtIssuerOptions options)
        {
            _options = options;
        }

        TokenVM ITokenManager.GenerateTokenFromClaims(ICollection<Claim> claims)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_options.JwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddMinutes(_options.JwtExpireInMinutes);

            IdentityModelEventSource.ShowPII = true;

            var token = new JwtSecurityToken(
                _options.JwtIssuer,
                _options.JwtAudience,
                claims,
                expires: expires,
                signingCredentials: creds
            );
            return new TokenVM()
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                tokenexptime = token.ValidTo.Subtract(token.ValidFrom).TotalMilliseconds
            };
        }
    }
}
