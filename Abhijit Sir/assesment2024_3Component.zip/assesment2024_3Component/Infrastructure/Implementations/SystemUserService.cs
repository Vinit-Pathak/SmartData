﻿using Core.Common.Constants;
using Core.Common.Interfaces;
using Core.Feature.Users.Request;
using Core.Feature.Users.Response;
using Dapper;
using Domain.Emums;
using Domain.ResponseMessage;
using Infrastructure.Dapper;
using Infrastructure.Persistence.Helpers;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Infrastructure.Implementations
{
    public class SystemUserService : ISystemUserService
    {
        private readonly ITokenManager _tokenManager;
        private readonly DapperContext _context;

        public SystemUserService(ITokenManager tokenManager, DapperContext context)
        {
            _tokenManager = tokenManager;
            _context = context;
        }

        // bussiness logic for add and update the user 
        public Task<ServiceResponse<string>> AddUpdateStaffUser(AddUpdateUserDto updateUserDto)
        {
            throw new NotImplementedException();
        }

        // bussiness logic for authenticate user
        public Task<ServiceResponse<AuthenticateUserVM>> AuthenticateUser(AuthenticateUserDto authenticateUser)
        {
            var response = new AuthenticateUserVM();
            try
            {
                if (authenticateUser.Email != TEMP_userData.UserMail)
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = AuthenticateUserResponseMessage.IncorrectUserMail;
                    response.AccessToken = null;
                    response.tokenExpiryTime = 0.0;
                    response.statuscode = 400;

                    return Task.FromResult(ResponseHelper.ServiceResponse(response, false, AuthenticateUserResponseMessage.IncorrectUserMail, (int)StatusCode.BadRequest));
                }
                else if (authenticateUser.password != TEMP_userData.password)
                {
                    response.IsSuccess = false;
                    response.ErrorMessage = AuthenticateUserResponseMessage.IncorrectPwd;
                    response.AccessToken = null;
                    response.tokenExpiryTime = 0.0;
                    response.statuscode = 400;

                    return Task.FromResult(ResponseHelper.ServiceResponse(response, false, AuthenticateUserResponseMessage.IncorrectPwd, (int)StatusCode.BadRequest));
                }
                else
                {
                    var claims = new List<Claim>
                    {
                        new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new(JwtRegisteredClaimNames.Email,authenticateUser.Email.ToString()),
                        new("password",authenticateUser.password.ToString()),
                        new("UserId",1.ToString())
                    };

                    var accessToken = _tokenManager.GenerateTokenFromClaims(claims);

                    response.IsSuccess = true;
                    response.ErrorMessage = AuthenticateUserResponseMessage.LoginSuccess;
                    response.AccessToken = accessToken.token;
                    response.tokenExpiryTime = accessToken.tokenexptime;
                    response.statuscode = 200;

                    return Task.FromResult(ResponseHelper.ServiceResponse(response, false, AuthenticateUserResponseMessage.LoginSuccess, (int)StatusCode.OK));
                }
            }
            catch
            {
                return Task.FromResult(ResponseHelper.ServiceResponse(response, false, AuthenticateUserResponseMessage.internalservererror, (int)StatusCode.InternalServerError));
            }
        }

        // Bussiness logic for getting the data form the stored procedure 
        public async Task<ServiceResponse<string>> GetUserdataByStoredProcedure(int UserId)
        {
            try
            {
                using var connection = _context.CreateConnection;
                connection.Open();

                var parameter = new DynamicParameters();
                parameter.Add(GetUserDataByuserIdSpParams.userId, UserId);

                var result = connection.QueryAsync<GetUserDataByUserIdVM>(
                    sql: GetUserDataByuserIdSpParams.SpName,
                    param: parameter,
                    commandType: CommandType.StoredProcedure
                );

                if (result != null)
                {
                    return ResponseHelper.ServiceResponse(CommonResponseMessages.Success, true, CommonResponseMessages.Found, Convert.ToInt32(StatusCode.Found));
                }
                else
                {
                    return ResponseHelper.ServiceResponse(CommonResponseMessages.Fail, false, CommonResponseMessages.NotFound, Convert.ToInt32(StatusCode.NotFound));
                }
            }
            catch
            {
                return ResponseHelper.ServiceResponse(CommonResponseMessages.Error, false, CommonResponseMessages.InternalServerError, Convert.ToInt32(StatusCode.InternalServerError));
            }
        }
    }
}
