﻿using Core.Common.Constants;

namespace Infrastructure.Persistence.Helpers
{
    public static class ResponseHelper
    {
        public static ServiceResponse<T> ServiceResponse<T>(T data, bool success = true, string message = "", int StatusCode = 0)
        {
            var response = new ServiceResponse<T>();
            response.Data = data;
            response.Success = success;
            response.Message = message;
            response.StatusCode = StatusCode;
            return response;
        }
    }
}
