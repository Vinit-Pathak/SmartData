﻿using Domain.Entities.Users;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration.Entites.SystemUserConfig
{
    public class SystemUserConfiguration : IEntityTypeConfiguration<SystemUsers>
    {
        public void Configure(EntityTypeBuilder<SystemUsers> builder)
        {
            // table primary key and table name declaration

            builder.ToTable(name: "SystemUser", schema: "assesment").HasKey(u => u.UserId);
            builder.ToTable(name: "SystemUser", schema: "assesment").Property(u => u.UserId).HasColumnName("UserId").UseIdentityColumn();

            // table property's
            builder.Property(u => u.UserFirstName).HasColumnName("UserFirstName").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.UserLastName).HasColumnName("UserLastName").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Email).HasColumnName("Email").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.City).HasColumnName("City").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.State).HasColumnName("State").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.ZipCode).HasColumnName("ZipCode").HasMaxLength(10).IsRequired(false);
            builder.Property(u => u.Address).HasColumnName("Address").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Contact).HasColumnName("Contact").HasMaxLength(20).IsRequired(false);
            builder.Property(u => u.Password).HasColumnName("Password").HasMaxLength(50).IsRequired(false);

        }
    }
}
