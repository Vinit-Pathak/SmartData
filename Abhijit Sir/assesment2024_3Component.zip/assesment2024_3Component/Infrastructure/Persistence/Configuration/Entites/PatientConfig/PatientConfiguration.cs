﻿using Domain.Entities.Patient;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration.Entites.PatientConfig
{
    public class PatientConfiguration : IEntityTypeConfiguration<Patient>
    {
        public void Configure(EntityTypeBuilder<Patient> builder)
        {
            // table primary key and table name declaration

            builder.ToTable(name: "Patient", schema: "assesment").HasKey(u => u.PatientId);
            builder.ToTable(name: "Patient", schema: "assesment").Property(u => u.PatientId).HasColumnName("PatientId").UseIdentityColumn();

            // table property's
            builder.Property(u => u.PatientFirstName).HasColumnName("PatientFirstName").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.PatientLastName).HasColumnName("PatientLastName").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Email).HasColumnName("Email").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.City).HasColumnName("City").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.State).HasColumnName("State").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.ZipCode).HasColumnName("ZipCode").HasMaxLength(10).IsRequired(false);
            builder.Property(u => u.Address).HasColumnName("Address").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Contact).HasColumnName("Contact").HasMaxLength(20).IsRequired(false);
        }
    }
}
