﻿using Domain.Entities.Provider;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration.Entites.ProviderConfig
{
    public class ProviderConfiguration : IEntityTypeConfiguration<Provider>
    {
        public void Configure(EntityTypeBuilder<Provider> builder)
        {
            // table primary key and table name declaration

            builder.ToTable(name: "Provider", schema: "assesment").HasKey(u => u.ProviderId);
            builder.ToTable(name: "Provider", schema: "assesment").Property(u => u.ProviderId).HasColumnName("ProviderId").UseIdentityColumn();

            // table property's
            builder.Property(u => u.ProviderName).HasColumnName("ProviderName").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Email).HasColumnName("Email").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.City).HasColumnName("City").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.State).HasColumnName("State").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.ZipCode).HasColumnName("ZipCode").HasMaxLength(10).IsRequired(false);
            builder.Property(u => u.Address).HasColumnName("Address").HasMaxLength(100).HasColumnType("NVARCHAR").IsRequired(false);
            builder.Property(u => u.Contact).HasColumnName("Contact").HasMaxLength(20).IsRequired(false);
        }
    }
}
