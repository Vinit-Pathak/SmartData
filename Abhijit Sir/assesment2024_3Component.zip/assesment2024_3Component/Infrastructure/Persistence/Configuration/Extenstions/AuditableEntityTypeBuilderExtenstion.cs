﻿using Domain.Common;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infrastructure.Persistence.Configuration.Extenstions
{
    public static class AuditableEntityTypeBuilderExtenstion
    {
        public static void ConfigureAuditableEntity<TEntity>(this EntityTypeBuilder<TEntity> builder) where TEntity : AuditableEntity
        {
            builder.Property(a => a.IsActive).HasMaxLength(5);
            builder.Property(a => a.IsDeleted).HasMaxLength(5);
            builder.Property(a => a.CreatedBy).HasMaxLength(5);
            builder.Property(a => a.CreatedOn).HasMaxLength(50);
            builder.Property(a => a.UpdatedBy).HasMaxLength(5);
            builder.Property(a => a.UpdatedOn).HasMaxLength(50);
            builder.Property(a => a.DeletedBy).HasMaxLength(5);
            builder.Property(a => a.DeletedOn).HasMaxLength(50);
        }
    }
}
