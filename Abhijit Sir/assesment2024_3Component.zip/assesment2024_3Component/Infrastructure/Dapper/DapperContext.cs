﻿using Core.Interface.Common;
using Domain.Entities.Customer;
using Domain.Entities.Patient;
using Domain.Entities.Provider;
using Domain.Entities.Users;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Reflection;

namespace Infrastructure.Dapper
{
    public class DapperContext : DbContext, IDapperContext
    {
        private readonly IConfiguration _configuration;

        public DapperContext(IConfiguration configuration, DbContextOptions options) : base(options) => _configuration = configuration;

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            base.OnModelCreating(builder);
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var result = await base.SaveChangesAsync(cancellationToken);

            return result;
        }

        public IDbConnection CreateConnection => new SqlConnection(_configuration.GetConnectionString("DefaultConnection"));

        public DbSet<SystemUsers> SystemUsers => Set<SystemUsers>();

        public DbSet<Patient> Patient => Set<Patient>();

        public DbSet<Provider> Provider => Set<Provider>();

        public DbSet<Customer> Customer => Set<Customer>();
    }
}
