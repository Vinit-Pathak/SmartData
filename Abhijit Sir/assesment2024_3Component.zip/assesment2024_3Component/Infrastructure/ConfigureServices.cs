﻿using Core.Common.Interfaces;
using Core.Interface.Common;
using Infrastructure.Dapper;
using Infrastructure.Implementation;
using Infrastructure.Implementations;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System.Text;

namespace Infrastructure
{
    public static class ConfigureServices
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<DapperContext>(option =>
            {
                option.UseSqlServer(configuration.GetConnectionString("DefaultConnection"),
                builder =>
                {
                    builder.MigrationsAssembly(typeof(DapperContext).Assembly.FullName);
                });
            });

            IJwtIssuerOptions jwtIssuerOptions = new JwtIssuerOptions(configuration);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = jwtIssuerOptions.JwtAudience,
                    ValidIssuer = jwtIssuerOptions.JwtIssuer,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtIssuerOptions.JwtKey))
                };
            });

            services.AddScoped<IDapperContext>(provider => provider.GetRequiredService<DapperContext>());

            /* Declaration of Services */
            services.AddTransient<IJwtIssuerOptions, JwtIssuerOptions>();
            services.AddTransient<ITokenManager, TokenManagerService>();
            services.AddTransient<ISystemUserService, SystemUserService>();

            return services;
        }
    }
}
