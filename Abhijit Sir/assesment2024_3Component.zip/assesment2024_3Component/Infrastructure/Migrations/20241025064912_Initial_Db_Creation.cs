﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Initial_Db_Creation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "assesment");

            migrationBuilder.CreateTable(
                name: "Customer",
                schema: "assesment",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerFirstName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    CustomerLastName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Email = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    City = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    State = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    ZipCode = table.Column<int>(type: "int", maxLength: 10, nullable: true),
                    Address = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Contact = table.Column<int>(type: "int", maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<int>(type: "int", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customer", x => x.CustomerId);
                });

            migrationBuilder.CreateTable(
                name: "Patient",
                schema: "assesment",
                columns: table => new
                {
                    PatientId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PatientFirstName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    PatientLastName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Email = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    City = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    State = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    ZipCode = table.Column<int>(type: "int", maxLength: 10, nullable: true),
                    Address = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Contact = table.Column<int>(type: "int", maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<int>(type: "int", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Patient", x => x.PatientId);
                });

            migrationBuilder.CreateTable(
                name: "Provider",
                schema: "assesment",
                columns: table => new
                {
                    ProviderId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProviderName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Email = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    City = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    State = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    ZipCode = table.Column<int>(type: "int", maxLength: 10, nullable: true),
                    Address = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Contact = table.Column<int>(type: "int", maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<int>(type: "int", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Provider", x => x.ProviderId);
                });

            migrationBuilder.CreateTable(
                name: "SystemUser",
                schema: "assesment",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFirstName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    UserLastName = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Email = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    City = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    State = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    ZipCode = table.Column<int>(type: "int", maxLength: 10, nullable: true),
                    Address = table.Column<string>(type: "NVARCHAR(100)", maxLength: 100, nullable: true),
                    Contact = table.Column<int>(type: "int", maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: true),
                    CreatedBy = table.Column<int>(type: "int", nullable: true),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UpdatedBy = table.Column<int>(type: "int", nullable: true),
                    UpdatedOn = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DeletedBy = table.Column<int>(type: "int", nullable: true),
                    DeletedOn = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SystemUser", x => x.UserId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Customer",
                schema: "assesment");

            migrationBuilder.DropTable(
                name: "Patient",
                schema: "assesment");

            migrationBuilder.DropTable(
                name: "Provider",
                schema: "assesment");

            migrationBuilder.DropTable(
                name: "SystemUser",
                schema: "assesment");
        }
    }
}
