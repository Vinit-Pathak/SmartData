﻿using Core.Feature.Users.Query;
using Core.Feature.Users.Request;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace Assesment2024.Controllers.SystemUserController
{
    [Route("api/[controller]")]
    [ApiController]
    public class SystemUserController : ControllerBase
    {
        private readonly IMediator _mediator;

        public SystemUserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // API for Authenticate User and genrating the JWT token 
        [HttpPost("[action]")]
        public async Task<IActionResult> AuthenticateUser(AuthenticateUserDto authenticateUserDto)
        {
            var result = await _mediator.Send(new AuthenticateUserQuery()
            {
                userDto = authenticateUserDto
            });

            return Ok(result);
        }


        // API for getting the User data form the DB by the stored Procedure 
        [HttpGet("[action]")]
        public async Task<IActionResult> GetUserDatabyStoredProcedure(int UserId)
        {
            var userdata = await _mediator.Send(new GetUserDataByUserIdQuery()
            {
                UserId = UserId
            });
            return Ok(userdata);
        }
    }
}
