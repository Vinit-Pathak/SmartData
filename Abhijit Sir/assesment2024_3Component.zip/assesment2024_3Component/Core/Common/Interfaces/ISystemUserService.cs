﻿using Core.Common.Constants;
using Core.Feature.Users.Request;
using Core.Feature.Users.Response;

namespace Core.Common.Interfaces
{
    public interface ISystemUserService
    {
        public Task<ServiceResponse<string>> AddUpdateStaffUser(AddUpdateUserDto addUpdateUser);
        public Task<ServiceResponse<AuthenticateUserVM>> AuthenticateUser(AuthenticateUserDto authenticateUser);

        public Task<ServiceResponse<string>> GetUserdataByStoredProcedure(int UserId);
    }
}
