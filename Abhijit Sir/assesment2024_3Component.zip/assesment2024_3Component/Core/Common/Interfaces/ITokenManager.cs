﻿using Core.Features.Account.Response;
using System.Security.Claims;

namespace Core.Common.Interfaces
{
    public interface ITokenManager
    {
        TokenVM GenerateTokenFromClaims(ICollection<Claim> claims);
    }
}
