﻿namespace Core.Common.Interfaces
{
    public interface IJwtIssuerOptions
    {
        public string JwtKey { get; }
        public string JwtIssuer { get; }
        public string JwtAudience { get; }
        public double JwtExpireInMinutes { get; }
    }
}
