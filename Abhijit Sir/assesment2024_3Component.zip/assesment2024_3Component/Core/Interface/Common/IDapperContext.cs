﻿using Domain.Entities.Customer;
using Domain.Entities.Patient;
using Domain.Entities.Provider;
using Domain.Entities.Users;
using Microsoft.EntityFrameworkCore;

namespace Core.Interface.Common
{
    public interface IDapperContext
    {
        DbSet<SystemUsers> SystemUsers { get; }
        DbSet<Patient> Patient { get; }
        DbSet<Provider> Provider { get; }
        DbSet<Customer> Customer { get; }
    }
}
