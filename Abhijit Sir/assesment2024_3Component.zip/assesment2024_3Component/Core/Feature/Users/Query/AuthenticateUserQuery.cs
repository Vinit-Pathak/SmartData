﻿using Core.Common.Constants;
using Core.Common.Interfaces;
using Core.Feature.Users.Request;
using Core.Feature.Users.Response;
using MediatR;

namespace Core.Feature.Users.Query
{
    public class AuthenticateUserQuery : IRequest<ServiceResponse<AuthenticateUserVM>>
    {
        public AuthenticateUserDto userDto { get; set; }
    }

    public class AuthenticateUserQueryHandler : IRequestHandler<AuthenticateUserQuery, ServiceResponse<AuthenticateUserVM>>
    {
        private readonly ISystemUserService _systemUserService;

        public AuthenticateUserQueryHandler(ISystemUserService systemUserService)
        {
            _systemUserService = systemUserService;
        }

        public async Task<ServiceResponse<AuthenticateUserVM>> Handle(AuthenticateUserQuery request, CancellationToken cancellationToken)
        {
            return await _systemUserService.AuthenticateUser(request.userDto);
        }
    }
}
