﻿using Core.Common.Constants;
using Core.Common.Interfaces;
using MediatR;

namespace Core.Feature.Users.Query
{
    public class GetUserDataByUserIdQuery : IRequest<ServiceResponse<string>>
    {
        public int UserId { get; set; }
    }
    public class GetUserDataByUserIdQueryHandler : IRequestHandler<GetUserDataByUserIdQuery, ServiceResponse<string>>
    {
        private readonly ISystemUserService _systemUserService;

        public GetUserDataByUserIdQueryHandler(ISystemUserService systemUserService)
        {
            _systemUserService = systemUserService;
        }

        public async Task<ServiceResponse<string>> Handle(GetUserDataByUserIdQuery request, CancellationToken cancellationToken)
        {
            return await _systemUserService.GetUserdataByStoredProcedure(request.UserId);
        }
    }
}
