﻿namespace Core.Feature.Users.Request
{
    public class AuthenticateUserDto
    {
        public string? Email { get; set; }
        public string? password { get; set; }
    }
}
