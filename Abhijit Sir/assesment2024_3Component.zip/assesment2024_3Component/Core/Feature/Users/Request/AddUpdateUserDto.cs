﻿namespace Core.Feature.Users.Request
{
    public class AddUpdateUserDto
    {
        public int UserId { get; set; }
        public string? UserFirstName { get; set; }
        public string? UserLastName { get; set; }
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? Address { get; set; }
        public int? Contact { get; set; }
    }
}
