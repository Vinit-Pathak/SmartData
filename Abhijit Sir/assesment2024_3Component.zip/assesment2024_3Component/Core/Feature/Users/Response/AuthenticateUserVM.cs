﻿namespace Core.Feature.Users.Response
{
    public class AuthenticateUserVM
    {
        public bool IsSuccess { get; set; }
        public string? AccessToken { get; set; }
        public string? ErrorMessage { get; set; }
        public int statuscode { get; set; }
        public double tokenExpiryTime { get; set; }
    }
}
