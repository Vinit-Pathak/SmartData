﻿namespace Core.Features.Account.Response
{
    public class TokenVM
    {
        public string token { get; set; }
        public double tokenexptime { get; set; }
    }
}
