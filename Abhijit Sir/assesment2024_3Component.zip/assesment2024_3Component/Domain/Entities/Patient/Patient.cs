﻿using Domain.Common;

namespace Domain.Entities.Patient
{
    public class Patient : AuditableEntity
    {
        public int PatientId { get; set; }
        public string? PatientFirstName { get; set; }
        public string? PatientLastName { get; set; }
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? Address { get; set; }
        public int? Contact { get; set; }
    }
}
