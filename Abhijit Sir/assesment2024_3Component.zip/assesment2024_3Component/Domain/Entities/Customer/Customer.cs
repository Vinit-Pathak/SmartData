﻿using Domain.Common;

namespace Domain.Entities.Customer
{
    public class Customer : AuditableEntity
    {
        public int CustomerId { get; set; }
        public string? CustomerFirstName { get; set; }
        public string? CustomerLastName { get; set; }
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? Address { get; set; }
        public int? Contact { get; set; }
    }
}
