﻿using Domain.Common;

namespace Domain.Entities.Provider
{
    public class Provider : AuditableEntity
    {
        public int ProviderId { get; set; }
        public string? ProviderName { get; set; }
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? Address { get; set; }
        public int? Contact { get; set; }
    }
}
