﻿using Domain.Common;

namespace Domain.Entities.Users
{
    public class SystemUsers : AuditableEntity
    {
        public int UserId { get; set; }
        public string? UserFirstName { get; set; }
        public string? UserLastName { get; set; }
        public string? Password { get; set; }
        public string? Email { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public int? ZipCode { get; set; }
        public string? Address { get; set; }
        public int? Contact { get; set; }
    }
}
