﻿namespace Domain.ResponseMessage
{
    public static class CommonResponseMessages
    {
        public const string Success = "Success";
        public const string Fail = "Fail";
        public const string Error = "Error";
        public const string InternalServerError = "Internal server error";
        public const string Found = "Rrcord found";
        public const string NotFound = "Record not found";

    }

    public static class AuthenticateUserResponseMessage
    {
        public const string LoginSuccess = "User logged in successfully";
        public const string Loginfailed = "login attempt failed";
        public const string IncorrectPwd = "Incorrect password";
        public const string IncorrectUserMail = "Entered mail does not exist in the system";
        public const string internalservererror = "Internal server error";

    }

    public static class TEMP_userData
    {
        public const string UserMail = "admin@yopmail.com";
        public const string password = "admin@1234";
    }

    public static class GetUserDataByuserIdSpParams
    {
        public const string SpName = "Stored_Procedure_Name";

        public const string userId = "UserId";
    }
}
